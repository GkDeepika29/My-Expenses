import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Tab, Currency, Transaction, RecurringTransaction, Category, Budget, Notification as NotificationType } from './types';
import { TABS, INITIAL_CATEGORIES, CATEGORIES_STORAGE_KEY, BUDGETS_STORAGE_KEY, INITIAL_PAYMENT_METHODS, PAYMENT_METHODS_STORAGE_KEY } from './constants';
import useTransactions from './hooks/useTransactions';
import AddTransaction from './components/AddTransaction';
import Dashboard from './components/Dashboard';
import TransactionList from './components/TransactionList';
import Management from './components/Management';
import Import from './components/Import';
import Recurring from './components/Recurring';
import Export from './components/Export';
import SideNav from './components/SideNav';
import { SettingsIcon, PlusIcon, CloseIcon } from './components/icons';
import SettingsModal from './components/SettingsModal';
import OnboardingModal from './components/OnboardingModal';
import Notification from './components/Notification';
import { useLanguage } from './context/LanguageContext';
import { processRecurringTransactions } from './utils/recurring';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>(Tab.TransactionList);
  const { 
    transactions, addTransaction, deleteTransaction, 
    recurringTransactions, addRecurringTransaction, deleteRecurringTransaction, setRecurringTransactions 
  } = useTransactions();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const { t } = useLanguage();
  
  const [showOnboarding, setShowOnboarding] = useState<boolean>(() => {
    return !localStorage.getItem('hasOnboarded');
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem(CATEGORIES_STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  const [budgets, setBudgets] = useState<Budget>(() => {
    const saved = localStorage.getItem(BUDGETS_STORAGE_KEY);
    return saved ? JSON.parse(saved) : {};
  });

  const [currency, setCurrency] = useState<Currency>(() => {
    const saved = localStorage.getItem('currency');
    return (saved as Currency) || 'INR';
  });

  const [aiConsent, setAiConsent] = useState<boolean>(() => {
    const saved = localStorage.getItem('aiConsent');
    return saved ? JSON.parse(saved) : false;
  });

  const [paymentMethods, setPaymentMethods] = useState<string[]>(() => {
      const saved = localStorage.getItem(PAYMENT_METHODS_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
  });
  
  const [notifications, setNotifications] = useState<NotificationType[]>([]);
  const notifiedBudgets = useMemo(() => new Set<string>(), []);

  useEffect(() => {
    localStorage.setItem(CATEGORIES_STORAGE_KEY, JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem(BUDGETS_STORAGE_KEY, JSON.stringify(budgets));
    // Reset notified budgets when budgets change
    notifiedBudgets.clear();
  }, [budgets, notifiedBudgets]);

  useEffect(() => {
    localStorage.setItem('currency', currency);
  }, [currency]);
  
  useEffect(() => {
    localStorage.setItem('aiConsent', JSON.stringify(aiConsent));
  }, [aiConsent]);

  useEffect(() => {
    localStorage.setItem(PAYMENT_METHODS_STORAGE_KEY, JSON.stringify(paymentMethods));
  }, [paymentMethods]);

  useEffect(() => {
    if (showOnboarding) return; // Don't process recurring tx during onboarding
    const lastCheck = localStorage.getItem('lastRecurringCheck');
    const { transactionsToAdd, updatedRecurringTxs } = processRecurringTransactions(recurringTransactions, lastCheck);

    if (transactionsToAdd.length > 0) {
        addTransaction(transactionsToAdd);
    }
    
    setRecurringTransactions(updatedRecurringTxs);
    localStorage.setItem('lastRecurringCheck', new Date().toISOString());
  }, [showOnboarding]); // Re-run if onboarding state changes

  const addNotification = useCallback((message: string, type: 'warning' | 'info' = 'warning') => {
      const newNotification: NotificationType = {
        id: Date.now(),
        message,
        type,
      };
      setNotifications(prev => [...prev, newNotification]);
  }, []);

  const removeNotification = (id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };
  
  const checkBudgets = useCallback((newTx: Omit<Transaction, 'id'>) => {
      if (newTx.type !== 'expense') return;

      const category = categories.find(c => c.name === newTx.category);
      if (!category) return;

      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);

      const checkItem = (key: string, name: string) => {
          const budget = budgets[key];
          if (!budget || budget <= 0 || notifiedBudgets.has(`${now.getFullYear()}-${now.getMonth()}-${key}`)) return;

          const spent = transactions.concat([ { ...newTx, id: 'temp' } ])
              .filter(tx => {
                  const txDate = new Date(tx.date);
                  const isSameCategory = tx.category === category.name;
                  const isSameSubCategory = key.includes('-') ? tx.subCategory === name : true;
                  return tx.type === 'expense' && isSameCategory && isSameSubCategory && txDate >= startOfMonth && txDate <= endOfMonth;
              })
              .reduce((sum, tx) => sum + tx.amount, 0);
          
          if (spent / budget >= 0.8) {
              addNotification(t('budgetWarning').replace('{item}', name));
              notifiedBudgets.add(`${now.getFullYear()}-${now.getMonth()}-${key}`);
          }
      };
      
      // Check category budget
      checkItem(category.id, category.name);
      // Check subcategory budget
      if (newTx.subCategory) {
          checkItem(`${category.id}-${newTx.subCategory}`, newTx.subCategory);
      }
  }, [categories, budgets, transactions, addNotification, notifiedBudgets, t]);


  const handleTransactionAdded = (transaction: Omit<Transaction, 'id'> | Omit<Transaction, 'id'>[]) => {
    const txArray = Array.isArray(transaction) ? transaction : [transaction];
    txArray.forEach(checkBudgets);

    addTransaction(transaction);
    setIsAddModalOpen(false);
    setActiveTab(Tab.TransactionList);
  };

  const handleRecurringTransactionAdded = (recurring: Omit<RecurringTransaction, 'id'>, addFirst: boolean) => {
    addRecurringTransaction(recurring);
    if (addFirst) {
        const firstTx: Omit<Transaction, 'id'> = {
            type: recurring.type,
            amount: recurring.amount,
            category: recurring.category,
            subCategory: recurring.subCategory,
            paymentMethod: recurring.paymentMethod,
            date: recurring.startDate,
            notes: recurring.notes,
        };
        handleTransactionAdded(firstTx); // Use handleTransactionAdded to trigger budget check
    } else {
        setIsAddModalOpen(false);
        setActiveTab(Tab.TransactionList);
    }
  };

  const handleOnboardingComplete = (config: { categories: Category[], paymentMethods: string[], currency: Currency }) => {
    setCategories(config.categories);
    setPaymentMethods(config.paymentMethods);
    setCurrency(config.currency);
    localStorage.setItem('hasOnboarded', 'true');
    setShowOnboarding(false);
  };

  const renderContent = useCallback(() => {
    switch (activeTab) {
      case Tab.TransactionList:
        return <TransactionList transactions={transactions} deleteTransaction={deleteTransaction} currency={currency} categories={categories} />;
      case Tab.Management:
        return <Management 
                  categories={categories} setCategories={setCategories}
                  budgets={budgets} setBudgets={setBudgets}
                  paymentMethods={paymentMethods} setPaymentMethods={setPaymentMethods}
                  transactions={transactions} currency={currency}
                />;
      case Tab.Import:
        return <Import addTransactions={handleTransactionAdded} categories={categories} setCategories={setCategories} />;
      case Tab.Recurring:
        return <Recurring recurringTransactions={recurringTransactions} deleteRecurringTransaction={deleteRecurringTransaction} currency={currency} />;
      case Tab.Export:
        return <Export transactions={transactions} />;
      case Tab.Dashboard:
      default:
        return <Dashboard transactions={transactions} currency={currency} categories={categories} budgets={budgets} />;
    }
  }, [activeTab, transactions, budgets, currency, categories, deleteTransaction, paymentMethods, setPaymentMethods, setCategories, setBudgets, recurringTransactions, deleteRecurringTransaction, handleTransactionAdded]);
  
  const getTitle = (tab: Tab): string => {
    const tabInfo = TABS.find(t => t.id === tab);
    return tabInfo ? t(tabInfo.titleKey) : t('appTitle');
  };

  if (showOnboarding) {
    return <OnboardingModal onClose={handleOnboardingComplete} />;
  }

  return (
    <div className="min-h-screen font-sans text-slate-800 dark:text-slate-200 bg-slate-50 dark:bg-slate-900 flex flex-col md:flex-row">
      <SideNav activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <div className="flex-1 flex flex-col w-full md:w-auto overflow-x-hidden">
        <header className="bg-white dark:bg-slate-800 shadow-md sticky top-0 z-10 md:relative">
            <div className="container mx-auto p-4 flex justify-between items-center max-w-5xl">
            <h1 className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">{getTitle(activeTab)}</h1>
            <button
                onClick={() => setIsSettingsOpen(true)}
                className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                aria-label={t('settingsTitle')}
            >
                <SettingsIcon />
            </button>
            </div>
        </header>
        
        <main className="flex-grow container mx-auto p-4 max-w-5xl">
            {renderContent()}
        </main>
      </div>

      {/* Add Transaction Modal */}
      {isAddModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-40 animate-fade-in-fast p-4">
              <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
                  <div className="sticky top-0 bg-white dark:bg-slate-800 p-4 border-b dark:border-slate-700 flex justify-between items-center z-10">
                      <h2 className="text-xl font-bold">{t('addTitle')}</h2>
                      <button onClick={() => setIsAddModalOpen(false)} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700" aria-label={t('close')}>
                          <CloseIcon />
                      </button>
                  </div>
                  <div className="p-4">
                     <AddTransaction onTransactionAdded={handleTransactionAdded} onRecurringTransactionAdded={handleRecurringTransactionAdded} aiConsent={aiConsent} categories={categories} currency={currency} paymentMethods={paymentMethods} />
                  </div>
              </div>
          </div>
      )}

      {/* FAB to open Add Transaction Modal */}
      <button
        onClick={() => setIsAddModalOpen(true)}
        className="fixed bottom-6 right-6 md:bottom-10 md:right-10 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full p-4 shadow-lg z-30 transform transition-transform hover:scale-110"
        aria-label={t('addTitle')}
      >
        <PlusIcon className="w-8 h-8"/>
      </button>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        currency={currency}
        setCurrency={setCurrency}
        aiConsent={aiConsent}
        setAiConsent={setAiConsent}
      />

      <Notification notifications={notifications} onRemove={removeNotification} />
    </div>
  );
};

export default App;