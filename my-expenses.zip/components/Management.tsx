import React, { useState, useMemo } from 'react';
import { Category, Budget, Transaction, Currency } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { ICONS } from '../constants';
import { TrashIcon, CategoryIcon, ChevronDownIcon, PlusIcon } from './icons';
import { formatCurrency } from '../utils/currency';

interface ManagementProps {
    categories: Category[];
    setCategories: (categories: Category[]) => void;
    budgets: Budget;
    setBudgets: (budgets: Budget) => void;
    paymentMethods: string[];
    setPaymentMethods: (methods: string[]) => void;
    transactions: Transaction[];
    currency: Currency;
}

const Management: React.FC<ManagementProps> = ({ 
    categories, setCategories, budgets, setBudgets, paymentMethods, setPaymentMethods, transactions, currency 
}) => {
    const { t, language } = useLanguage();
    const [newCategoryName, setNewCategoryName] = useState('');
    const [newCategoryIcon, setNewCategoryIcon] = useState(ICONS[0]);
    const [isAddingCategory, setIsAddingCategory] = useState(false);
    
    const [expandedCategoryId, setExpandedCategoryId] = useState<string | null>(null);
    const [newSubCategoryNames, setNewSubCategoryNames] = useState<Record<string, string>>({});
    
    const [newMethod, setNewMethod] = useState('');

    const spentPerItem = useMemo(() => {
        const now = new Date();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

        return transactions.reduce((acc, tx) => {
            const category = categories.find(c => c.name === tx.category);
            const txDate = new Date(tx.date);

            if (tx.type === 'expense' && category && txDate >= startOfMonth) {
                // Main category spending
                acc[category.id] = (acc[category.id] || 0) + tx.amount;
                // Subcategory spending
                if (tx.subCategory) {
                    const subKey = `${category.id}-${tx.subCategory}`;
                    acc[subKey] = (acc[subKey] || 0) + tx.amount;
                }
            }
            return acc;
        }, {} as Record<string, number>);
    }, [transactions, categories]);

    const handleAddCategory = () => {
        if (newCategoryName.trim() && !categories.some(c => c.name.toLowerCase() === newCategoryName.trim().toLowerCase())) {
            const newCategory: Category = {
                id: `cat-${Date.now()}`,
                name: newCategoryName.trim(),
                icon: newCategoryIcon,
                subCategories: [],
            };
            // FIX: Use prop 'categories' instead of updater function to align with prop type.
            setCategories([...categories, newCategory].sort((a,b) => a.name.localeCompare(b.name)));
            setNewCategoryName('');
            setNewCategoryIcon(ICONS[0]);
            setIsAddingCategory(false);
        }
    };

    const handleDeleteCategory = (id: string) => {
        setCategories(categories.filter(c => c.id !== id));
        const newBudgets = { ...budgets };
        delete newBudgets[id];
        setBudgets(newBudgets);
    };

    const handleAddSubCategory = (categoryId: string) => {
        const subCategoryName = newSubCategoryNames[categoryId]?.trim();
        if (!subCategoryName) return;

        setCategories(categories.map(cat => {
            if (cat.id === categoryId && !cat.subCategories.find(s => s.toLowerCase() === subCategoryName.toLowerCase())) {
                return { ...cat, subCategories: [...cat.subCategories, subCategoryName].sort() };
            }
            return cat;
        }));
        setNewSubCategoryNames({ ...newSubCategoryNames, [categoryId]: '' });
    };
    
    const handleDeleteSubCategory = (categoryId: string, subCategoryName: string) => {
        setCategories(categories.map(cat => {
            if (cat.id === categoryId) {
                return { ...cat, subCategories: cat.subCategories.filter(s => s !== subCategoryName) };
            }
            return cat;
        }));
    };
    
    const handleBudgetChange = (key: string, value: string) => {
        // FIX: Use prop 'budgets' instead of updater function to align with prop type.
        const newBudgets = { ...budgets };
        const amount = parseFloat(value);
        if (!isNaN(amount) && amount >= 0) {
            newBudgets[key] = amount;
        } else {
            delete newBudgets[key];
        }
        setBudgets(newBudgets);
    };

    const handleAddPaymentMethod = () => {
        if (newMethod.trim() && !paymentMethods.find(m => m.toLowerCase() === newMethod.trim().toLowerCase())) {
            // FIX: Use prop 'paymentMethods' instead of updater function to align with prop type.
            setPaymentMethods([...paymentMethods, newMethod.trim()].sort());
            setNewMethod('');
        }
    };

    const handleDeletePaymentMethod = (methodToDelete: string) => {
        setPaymentMethods(paymentMethods.filter(m => m !== methodToDelete));
    };

    const BudgetInput = ({ itemKey, label }: { itemKey: string, label: string }) => {
        const spent = spentPerItem[itemKey] || 0;
        const budget = budgets[itemKey] || 0;
        const progress = budget > 0 ? (spent / budget) * 100 : 0;
        
        return (
            <div className="mt-2">
                <label htmlFor={`budget-${itemKey}`} className="text-xs font-medium text-slate-500 dark:text-slate-400">{label}</label>
                <div className="relative mt-1">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-sm text-slate-500 dark:text-slate-400">{formatCurrency(0, currency, language, 0).replace(/[0-9.,\s]/g, '')}</span>
                    <input type="number" id={`budget-${itemKey}`} value={budgets[itemKey] || ''} onChange={(e) => handleBudgetChange(itemKey, e.target.value)} placeholder="0" className="w-full pl-7 pr-2 py-1 text-sm bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md"/>
                </div>
                {budget > 0 &&
                    <div className="mt-2">
                        <div className="flex justify-between text-xs font-medium text-slate-600 dark:text-slate-300">
                            <span>{t('spent')}: {formatCurrency(spent, currency, language)}</span>
                            <span>{formatCurrency(budget, currency, language)}</span>
                        </div>
                        <div className="w-full bg-slate-200 dark:bg-slate-600 rounded-full h-2 mt-1"><div className={`h-2 rounded-full ${progress > 100 ? 'bg-red-500' : progress > 80 ? 'bg-amber-500' : 'bg-indigo-500'}`} style={{ width: `${Math.min(progress, 100)}%` }}></div></div>
                    </div>
                }
            </div>
        );
    }

    return (
        <div className="space-y-8 animate-fade-in">
            {/* Category and Budget Management */}
            <section>
                <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200 mb-4">{t('manageCategories')}</h2>
                <div className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-lg space-y-4">
                    {!isAddingCategory ? (
                        <button onClick={() => setIsAddingCategory(true)} className="w-full flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700">
                            <PlusIcon className="w-5 h-5 mr-2" />
                            {t('addNewCategory')}
                        </button>
                    ) : (
                        <div className="p-3 bg-slate-100 dark:bg-slate-700 rounded-lg space-y-2 animate-fade-in-fast">
                            <div className="flex flex-col sm:flex-row gap-2">
                                <input type="text" value={newCategoryName} onChange={e => setNewCategoryName(e.target.value)} placeholder={t('newCategoryName')} className="flex-grow px-3 py-2 bg-white dark:bg-slate-600 border border-slate-300 dark:border-slate-500 rounded-md shadow-sm sm:text-sm"/>
                                <select id="icon" value={newCategoryIcon} onChange={e => setNewCategoryIcon(e.target.value)} className="px-3 py-2 bg-white dark:bg-slate-600 border border-slate-300 dark:border-slate-500 rounded-md shadow-sm">
                                    {ICONS.map(icon => <option key={icon} value={icon}>{icon}</option>)}
                                </select>
                            </div>
                             <div className="flex gap-2">
                                <button onClick={handleAddCategory} className="flex-1 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">{t('add')}</button>
                                <button onClick={() => setIsAddingCategory(false)} className="flex-1 px-4 py-2 text-sm font-medium bg-slate-200 dark:bg-slate-500 rounded-md hover:bg-slate-300 dark:hover:bg-slate-400">{t('close')}</button>
                            </div>
                        </div>
                    )}
                    <div className="mt-4 max-h-[60vh] overflow-y-auto space-y-2 pr-2">
                    {categories.map(cat => (
                        <div key={cat.id} className="bg-slate-100 dark:bg-slate-700/50 rounded-lg">
                            <div className="p-3">
                                <div className="flex justify-between items-center">
                                    <div className="flex items-center space-x-3">
                                        <CategoryIcon name={cat.icon} className="w-8 h-8"/>
                                        <span className="font-semibold">{cat.name}</span>
                                    </div>
                                    <div className="flex items-center space-x-1">
                                        <button onClick={() => setExpandedCategoryId(expandedCategoryId === cat.id ? null : cat.id)} className="p-1 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600"><ChevronDownIcon className={`w-5 h-5 transition-transform ${expandedCategoryId === cat.id ? 'rotate-180' : ''}`} /></button>
                                        <button onClick={() => handleDeleteCategory(cat.id)} className="p-1 text-red-500 hover:text-red-700 rounded-full hover:bg-red-100 dark:hover:bg-red-900/50"><TrashIcon className="w-4 h-4" /></button>
                                    </div>
                                </div>
                                <BudgetInput itemKey={cat.id} label={t('monthlyBudget')} />
                            </div>
                            {expandedCategoryId === cat.id && (
                                <div className="p-3 border-t border-slate-200 dark:border-slate-600 space-y-3 animate-fade-in-fast">
                                    <h4 className="text-sm font-semibold">{t('subCategory')}</h4>
                                    {cat.subCategories.map(sub => (
                                        <div key={sub} className="bg-white dark:bg-slate-600 p-2 rounded-md">
                                            <div className="flex justify-between items-center">
                                                <span className="text-sm pl-2">{sub}</span>
                                                <button onClick={() => handleDeleteSubCategory(cat.id, sub)} className="p-1 text-red-500 hover:text-red-700 rounded-full hover:bg-red-100 dark:hover:bg-red-900/50"><TrashIcon className="w-3 h-3" /></button>
                                            </div>
                                            <BudgetInput itemKey={`${cat.id}-${sub}`} label={t('monthlyBudget')} />
                                        </div>
                                    ))}
                                    {cat.subCategories.length === 0 && <p className="text-xs text-slate-500 dark:text-slate-400 text-center py-2">No subcategories.</p>}
                                    <div className="flex space-x-2 pt-1">
                                        <input type="text" value={newSubCategoryNames[cat.id] || ''} onKeyDown={e => e.key === 'Enter' && handleAddSubCategory(cat.id)} onChange={e => setNewSubCategoryNames({...newSubCategoryNames, [cat.id]: e.target.value})} placeholder={t('newSubCategoryName')} className="flex-grow px-2 py-1 text-sm bg-white dark:bg-slate-600 border border-slate-300 dark:border-slate-500 rounded-md"/>
                                        <button onClick={() => handleAddSubCategory(cat.id)} className="px-3 py-1 text-sm font-medium text-white bg-indigo-500 rounded-md hover:bg-indigo-600">{t('add')}</button>
                                    </div>
                                </div>
                            )}
                        </div>
                    ))}
                    </div>
                </div>
            </section>
            
            {/* Payment Method Management */}
            <section>
                 <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200 mb-4">{t('managePaymentMethods')}</h2>
                 <div className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-lg">
                    <div className="flex space-x-2 mb-2">
                        <input type="text" value={newMethod} onKeyDown={e => e.key === 'Enter' && handleAddPaymentMethod()} onChange={e => setNewMethod(e.target.value)} placeholder={t('newPaymentMethod')} className="flex-grow px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm sm:text-sm" />
                        <button type="button" onClick={handleAddPaymentMethod} className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700">{t('add')}</button>
                    </div>
                    <div className="max-h-48 overflow-y-auto space-y-1 pr-2">
                        {paymentMethods.map(method => (
                            <div key={method} className="flex justify-between items-center bg-slate-100 dark:bg-slate-700 p-2 rounded-md">
                                <span className="text-sm font-medium ml-2">{method}</span>
                                <button onClick={() => handleDeletePaymentMethod(method)} className="p-1 text-red-500 hover:text-red-700 rounded-full hover:bg-red-100 dark:hover:bg-red-900/50"><TrashIcon className="w-4 h-4" /></button>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Management;