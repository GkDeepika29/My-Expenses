import React, { useEffect } from 'react';
import { Notification as NotificationType } from '../types';
import { CloseIcon } from './icons';

interface NotificationProps {
  notifications: NotificationType[];
  onRemove: (id: number) => void;
}

const Notification: React.FC<NotificationProps> = ({ notifications, onRemove }) => {
  return (
    <div className="fixed top-4 right-4 z-50 space-y-2 w-full max-w-xs">
      {notifications.map(notification => (
        <Toast key={notification.id} notification={notification} onRemove={onRemove} />
      ))}
    </div>
  );
};

interface ToastProps {
  notification: NotificationType;
  onRemove: (id: number) => void;
}

const Toast: React.FC<ToastProps> = ({ notification, onRemove }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onRemove(notification.id);
        }, 5000); // Auto-dismiss after 5 seconds

        return () => clearTimeout(timer);
    }, [notification, onRemove]);

    const bgColor = notification.type === 'warning' 
        ? 'bg-amber-100 dark:bg-amber-900/50 border-amber-400' 
        : 'bg-blue-100 dark:bg-blue-900/50 border-blue-400';
    const textColor = notification.type === 'warning' 
        ? 'text-amber-800 dark:text-amber-200' 
        : 'text-blue-800 dark:text-blue-200';

    return (
        <div className={`relative p-4 border-l-4 rounded-md shadow-lg animate-fade-in-right ${bgColor} ${textColor}`}>
            <p className="text-sm font-medium">{notification.message}</p>
            <button
                onClick={() => onRemove(notification.id)}
                className="absolute top-1 right-1 p-1 rounded-full hover:bg-black/10"
                aria-label="Close"
            >
                <CloseIcon className="w-4 h-4" />
            </button>
        </div>
    );
};

export default Notification;
