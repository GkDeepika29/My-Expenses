import { GoogleGenAI, Type } from "@google/genai";
import { Language, TransactionType, Category } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not set. AI features will not work.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });
const model = 'gemini-2.5-flash';

const getResponseSchema = (categoryNames: string[]) => ({
    type: Type.OBJECT,
    properties: {
        type: {
            type: Type.STRING,
            description: "The type of transaction. Must be either 'income' or 'expense'. Determine this from the context of the user's text.",
            enum: ['income', 'expense'],
        },
        amount: {
            type: Type.NUMBER,
            description: 'The numeric transaction amount. Should be greater than 0.',
        },
        category: {
            type: Type.STRING,
            description: `The category of the transaction. Must be one of: ${categoryNames.join(', ')}. Default to 'Other' if unsure.`,
            enum: categoryNames
        },
        notes: {
            type: Type.STRING,
            description: 'A brief note about the transaction, like the item purchased, store name, or source of income. Keep it concise.',
        },
    },
    required: ['type', 'amount', 'category'],
});

const getLanguageName = (langCode: Language): string => {
    switch (langCode) {
        case 'te': return 'Telugu';
        case 'ta': return 'Tamil';
        case 'hi': return 'Hindi';
        case 'en': 
        default: return 'English';
    }
}

interface ParsedData {
    type: TransactionType;
    amount: number;
    category: string;
    notes: string;
}

export const parseTransactionFromText = async (text: string, language: Language, categories: Category[]) => {
  if (!API_KEY) throw new Error("API Key is not configured.");
  const categoryNames = categories.map(c => c.name);
  
  const prompt = `
    The user is adding a financial transaction to their budget app using voice.
    The user's language is ${getLanguageName(language)}.
    Here is the transcribed text: "${text}"
    Analyze the text to determine if it is an 'income' (money received) or an 'expense' (money spent).
    Extract the transaction amount, a suitable category, and a brief note.
    The available categories are: ${categoryNames.join(', ')}.
    The current date is ${new Date().toLocaleDateString()}.
    Please return the data in the specified JSON format.
  `;

  try {
    const response = await ai.models.generateContent({
        model: model,
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: getResponseSchema(categoryNames),
        }
    });
    const jsonString = response.text.trim();
    return JSON.parse(jsonString) as ParsedData;
  } catch (error) {
    console.error('Error parsing transaction from text:', error);
    throw new Error('Failed to parse transaction from text.');
  }
};

export const parseTransactionFromImage = async (base64Image: string, mimeType: string, categories: Category[]) => {
    if (!API_KEY) throw new Error("API Key is not configured.");
    const categoryNames = categories.map(c => c.name);

    const prompt = `
        Analyze this receipt image. This is an 'expense'.
        Extract the total amount paid.
        Suggest a relevant expense category from the following list: ${categoryNames.join(', ')}.
        Also extract the store name or a short description for the notes.
        Return the data in the specified JSON format. If you cannot determine a value, omit the key or use a sensible default (e.g., 'Other' for category).
    `;

    const imagePart = {
        inlineData: {
            data: base64Image,
            mimeType: mimeType
        }
    };

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: { parts: [ { text: prompt }, imagePart ] },
            config: {
                responseMimeType: 'application/json',
                responseSchema: getResponseSchema(categoryNames),
            }
        });

        const jsonString = response.text.trim();
        return JSON.parse(jsonString) as ParsedData;
    } catch(error) {
        console.error('Error parsing transaction from image:', error);
        throw new Error('Failed to parse transaction from image.');
    }
};