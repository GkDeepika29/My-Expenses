import React from 'react';
import { Tab } from '../types';
import { TABS } from '../constants';
import { useLanguage } from '../context/LanguageContext';

const SideNav: React.FC<{ activeTab: Tab; setActiveTab: (tab: Tab) => void; }> = ({ activeTab, setActiveTab }) => {
  const { t } = useLanguage();

  return (
    <aside className="w-full md:w-56 flex-shrink-0 bg-white dark:bg-slate-800 shadow-lg flex md:flex-col justify-between">
      <div>
        <div className="p-4 border-b border-slate-200 dark:border-slate-700 hidden md:block">
          <h2 className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">{t('appTitle')}</h2>
        </div>
        <nav className="flex md:flex-col justify-around md:p-4 md:space-y-2">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 md:w-full flex flex-col md:flex-row items-center md:justify-start md:space-x-3 p-2 md:px-4 md:py-3 text-sm font-medium md:rounded-lg transition-colors duration-200 ${
                activeTab === tab.id
                  ? 'text-indigo-700 dark:text-indigo-300 md:bg-indigo-100 md:dark:bg-indigo-900/50 border-b-2 md:border-b-0 border-indigo-500'
                  : 'text-slate-600 dark:text-slate-300 hover:md:bg-slate-100 hover:dark:md:bg-slate-700 border-b-2 md:border-b-0 border-transparent'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              <span className="mt-1 md:mt-0">{t(tab.titleKey)}</span>
            </button>
          ))}
        </nav>
      </div>
    </aside>
  );
};

export default SideNav;