import React, { useState, useMemo } from 'react';
import { Transaction, Currency, Category } from '../types';
import { TrashIcon, RepeatIcon, CategoryIcon, ChevronLeftIcon, ChevronRightIcon } from './icons';
import { useLanguage } from '../context/LanguageContext';
import { formatCurrency } from '../utils/currency';

interface TransactionListProps {
  transactions: Transaction[];
  deleteTransaction: (id: string) => void;
  currency: Currency;
  categories: Category[];
}

const TransactionList: React.FC<TransactionListProps> = ({ transactions, deleteTransaction, currency, categories }) => {
  const { t, language } = useLanguage();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const categoryMap = useMemo(() => {
    return categories.reduce((acc, cat) => {
        acc[cat.name] = cat;
        return acc;
    }, {} as Record<string, Category>);
  }, [categories]);

  const filteredTransactions = useMemo(() => {
    return transactions.filter(tx => tx.date.startsWith(selectedDate));
  }, [transactions, selectedDate]);

  const changeDate = (offset: number) => {
      const currentDate = new Date(selectedDate);
      currentDate.setUTCDate(currentDate.getUTCDate() + offset);
      setSelectedDate(currentDate.toISOString().split('T')[0]);
  }

  if (transactions.length === 0) {
    return (
      <div className="text-center py-20 animate-fade-in">
        <p className="text-slate-500 dark:text-slate-400">{t('noTransactionsFound')}</p>
      </div>
    );
  }

  const dayTotal = filteredTransactions.reduce((sum, tx) => sum + (tx.type === 'income' ? tx.amount : -tx.amount), 0);
  const isToday = new Date().toISOString().split('T')[0] === selectedDate;

  return (
    <div className="space-y-4 animate-fade-in">
        <div className="sticky top-[72px] md:top-0 bg-slate-50 dark:bg-slate-900 py-2 z-5">
            <div className="flex items-center gap-2">
                <button onClick={() => changeDate(-1)} className="p-2 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700"><ChevronLeftIcon /></button>
                <input 
                    type="date" 
                    value={selectedDate} 
                    onChange={e => setSelectedDate(e.target.value)} 
                    className="flex-grow px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-center"
                />
                <button onClick={() => changeDate(1)} className="p-2 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700"><ChevronRightIcon /></button>
            </div>
            {!isToday && 
                <div className="text-center mt-2">
                    <button 
                        onClick={() => setSelectedDate(new Date().toISOString().split('T')[0])}
                        className="px-3 py-1 text-xs font-medium text-white bg-indigo-600 rounded-full hover:bg-indigo-700"
                    >
                        {t('today')}
                    </button>
                </div>
            }
        </div>

      {filteredTransactions.length > 0 ? (
        <div className="space-y-3">
          <div className="flex justify-between items-center bg-slate-100 dark:bg-slate-800 p-2 rounded-md font-semibold">
                <span>Total for day</span>
                <span className={`${dayTotal >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                    {formatCurrency(dayTotal, currency, language)}
                </span>
          </div>
          {filteredTransactions.map(tx => {
            const category = categoryMap[tx.category];
            const iconName = category ? category.icon : 'Other';

            return (
              <div 
                key={tx.id} 
                className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-md flex items-center justify-between"
              >
                <div className="flex items-center space-x-4">
                  <div className={`p-2 rounded-full ${tx.type === 'income' ? 'bg-green-100 dark:bg-green-900/50' : 'bg-red-100 dark:bg-red-900/50'}`}>
                    <CategoryIcon name={iconName} className={`w-5 h-5 ${tx.type === 'income' ? 'text-green-500' : 'text-red-500'}`} />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                       <p className="font-semibold text-slate-800 dark:text-slate-100">{tx.category}</p>
                       {tx.subCategory && <p className="text-sm text-slate-500 dark:text-slate-400">&gt; {tx.subCategory}</p>}
                       {tx.sourceRecurringId && <RepeatIcon className="w-4 h-4 text-slate-400" title={t('recurring')} />}
                    </div>
                     <p className="text-sm text-slate-500 dark:text-slate-400">{tx.notes || 'No notes'}</p>
                     {tx.paymentMethod && <span className="text-xs font-semibold bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-full mt-1 inline-block">{tx.paymentMethod}</span>}
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <p className={`font-bold text-lg ${tx.type === 'income' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                    {tx.type === 'income' ? '+' : '-'}{formatCurrency(tx.amount, currency, language)}
                  </p>
                  <button
                    onClick={() => deleteTransaction(tx.id)}
                    className="p-2 text-red-500 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900/50 rounded-full transition-colors"
                    aria-label={`${t('delete')} ${tx.category} transaction`}
                  >
                    <TrashIcon />
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      ) : (
         <div className="text-center py-20">
            <p className="text-slate-500 dark:text-slate-400">{t('noTransactionsForDate')}</p>
        </div>
      )}
    </div>
  );
};

export default TransactionList;