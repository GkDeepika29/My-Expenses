import { Tab, Language, Currency } from './types';
import { DashboardIcon, ListIcon, ManagementIcon, ImportIcon, RecurringIcon, ExportIcon } from './components/icons';

// A list of available icon names for categories.
// The component name must exist in components/icons.tsx
export const ICONS = [
    'Food', 'Travel', 'Shopping', 'Entertainment', 'Health', 'Bills', 'Salary', 'Freelance', 'Other',
    'Car', 'Home', 'Gift', 'Education', 'Investment', 'Fitness', 'Pets'
];

export interface InitialCategory {
  id: string;
  nameKey: string;
  icon: string;
  subCategoriesKeys: string[];
}

export const INITIAL_CATEGORIES: InitialCategory[] = [
  { id: 'cat-1', nameKey: "cat_food", icon: 'Food', subCategoriesKeys: ["sub_groceries", "sub_restaurant", "sub_breakfast", "sub_lunch", "sub_snacks"] },
  { id: 'cat-2', nameKey: "cat_travel", icon: 'Travel', subCategoriesKeys: ["sub_flight", "sub_hotel", "sub_train", "sub_taxi", "sub_fuel"] },
  { id: 'cat-3', nameKey: "cat_shopping", icon: 'Shopping', subCategoriesKeys: ["sub_clothes", "sub_electronics", "sub_gifts", "sub_home_goods"] },
  { id: 'cat-4', nameKey: "cat_entertainment", icon: 'Entertainment', subCategoriesKeys: ["sub_movies", "sub_games", "sub_concerts", "sub_streaming"] },
  { id: 'cat-5', nameKey: "cat_health", icon: 'Health', subCategoriesKeys: ["sub_doctor", "sub_pharmacy", "sub_gym", "sub_insurance"] },
  { id: 'cat-6', nameKey: "cat_bills", icon: 'Bills', subCategoriesKeys: ["sub_rent", "sub_electricity", "sub_internet", "sub_phone", "sub_water"] },
  { id: 'cat-7', nameKey: "cat_salary", icon: 'Salary', subCategoriesKeys: ["sub_primary", "sub_bonus"] },
  { id: 'cat-8', nameKey: "cat_freelance", icon: 'Freelance', subCategoriesKeys: [] },
  { id: 'cat-9', nameKey: "cat_other", icon: 'Other', subCategoriesKeys: [] },
];

export const INITIAL_PAYMENT_METHODS: string[] = ['pm_cash', 'pm_phonepe', 'pm_gpay', 'pm_paytm', 'pm_credit_card', 'pm_debit_card', 'pm_bank_transfer'];

export const LANGUAGES: { id: Language; name: string }[] = [
  { id: 'en', name: 'English' },
  { id: 'te', name: 'తెలుగు' },
  { id: 'ta', name: 'தமிழ்' },
  { id: 'hi', name: 'हिन्दी' },
];

export const CURRENCIES: { id: Currency; name: string; symbol: string }[] = [
    { id: 'INR', name: 'Indian Rupee', symbol: '₹' },
    { id: 'USD', name: 'US Dollar', symbol: '$' },
    { id: 'EUR', name: 'Euro', symbol: '€' },
    { id: 'KWD', name: 'Kuwaiti Dinar', symbol: 'KD' },
    { id: 'GBP', name: 'British Pound', symbol: '£' },
    { id: 'JPY', name: 'Japanese Yen', symbol: '¥' },
    { id: 'AUD', name: 'Australian Dollar', symbol: 'A$' },
    { id: 'CAD', name: 'Canadian Dollar', symbol: 'C$' },
];

export const TRANSACTIONS_STORAGE_KEY = 'myTransactionsData_v3';
export const RECURRING_TRANSACTIONS_STORAGE_KEY = 'myRecurringTransactionsData_v3';
export const CATEGORIES_STORAGE_KEY = 'myCategoriesData_v3';
export const BUDGETS_STORAGE_KEY = 'myBudgetsData_v3';
export const PAYMENT_METHODS_STORAGE_KEY = 'myPaymentMethods_v3';

export const TABS = [
    { id: Tab.TransactionList, titleKey: 'transactionsTitle', icon: ListIcon },
    { id: Tab.Management, titleKey: 'managementTitle', icon: ManagementIcon },
    { id: Tab.Import, titleKey: 'importData', icon: ImportIcon },
    { id: Tab.Recurring, titleKey: 'manageRecurring', icon: RecurringIcon },
    { id: Tab.Export, titleKey: 'exportTitle', icon: ExportIcon },
    { id: Tab.Dashboard, titleKey: 'dashboardTitle', icon: DashboardIcon },
];