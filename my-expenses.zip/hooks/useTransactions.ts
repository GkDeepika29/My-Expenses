import { useState, useEffect } from 'react';
import { Transaction, RecurringTransaction } from '../types';
import { TRANSACTIONS_STORAGE_KEY, RECURRING_TRANSACTIONS_STORAGE_KEY } from '../constants';

const useTransactions = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [recurringTransactions, setRecurringTransactions] = useState<RecurringTransaction[]>([]);

  useEffect(() => {
    // Load standard transactions
    try {
      const storedData = localStorage.getItem(TRANSACTIONS_STORAGE_KEY);
      if (storedData) {
        const parsedData: Transaction[] = JSON.parse(storedData);
        parsedData.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        setTransactions(parsedData);
      }
    } catch (error) {
      console.error("Failed to load transactions from local storage", error);
      setTransactions([]);
    }
    // Load recurring transactions
    try {
      const storedRecurringData = localStorage.getItem(RECURRING_TRANSACTIONS_STORAGE_KEY);
      if (storedRecurringData) {
        setRecurringTransactions(JSON.parse(storedRecurringData));
      }
    } catch (error) {
      console.error("Failed to load recurring transactions from local storage", error);
      setRecurringTransactions([]);
    }
  }, []);

  const saveTransactions = (updatedTransactions: Transaction[]) => {
    updatedTransactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    localStorage.setItem(TRANSACTIONS_STORAGE_KEY, JSON.stringify(updatedTransactions));
    setTransactions(updatedTransactions);
  };
  
  const saveRecurringTransactions = (updatedRecurring: RecurringTransaction[]) => {
      localStorage.setItem(RECURRING_TRANSACTIONS_STORAGE_KEY, JSON.stringify(updatedRecurring));
      setRecurringTransactions(updatedRecurring);
  };

  const addTransaction = (newTransactions: Omit<Transaction, 'id'> | Omit<Transaction, 'id'>[]) => {
    const transactionsArray = Array.isArray(newTransactions) ? newTransactions : [newTransactions];
    const transactionsWithIds: Transaction[] = transactionsArray.map(tx => ({ ...tx, id: new Date().toISOString() + Math.random() }));
    saveTransactions([...transactionsWithIds, ...transactions]);
  };

  const deleteTransaction = (id: string) => {
    const updatedTransactions = transactions.filter(tx => tx.id !== id);
    saveTransactions(updatedTransactions);
  };
  
  const addRecurringTransaction = (newRecurring: Omit<RecurringTransaction, 'id'>) => {
    const recurringWithId: RecurringTransaction = { ...newRecurring, id: new Date().toISOString() + Math.random() };
    saveRecurringTransactions([recurringWithId, ...recurringTransactions]);
  };
  
  const deleteRecurringTransaction = (id: string) => {
    const updatedRecurring = recurringTransactions.filter(rtx => rtx.id !== id);
    saveRecurringTransactions(updatedRecurring);
    // Also delete generated transactions from this source
    const updatedTransactions = transactions.filter(tx => tx.sourceRecurringId !== id);
    saveTransactions(updatedTransactions);
  };

  return { 
    transactions, addTransaction, deleteTransaction, 
    recurringTransactions, addRecurringTransaction, deleteRecurringTransaction, setRecurringTransactions: saveRecurringTransactions 
  };
};

export default useTransactions;