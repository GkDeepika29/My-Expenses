import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Transaction, Category } from '../types';

interface ImportProps {
  addTransactions: (transactions: Omit<Transaction, 'id'>[]) => void;
  categories: Category[];
  setCategories: (categories: Category[]) => void;
}

const Import: React.FC<ImportProps> = ({ addTransactions, categories, setCategories }) => {
  const { t } = useLanguage();
  const [importStatus, setImportStatus] = useState<{ type: 'success' | 'error', message: string } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const parseAndImportCsv = (fileContent: string) => {
    setIsProcessing(true);
    setImportStatus(null);
    try {
        const lines = fileContent.split(/\r\n|\n/).filter(line => line.trim() !== '');
        if (lines.length < 2) {
            throw new Error("CSV must have a header and at least one data row.");
        }
        
        const header = lines[0].split(',').map(h => h.trim().toLowerCase());
        const dateIndex = header.indexOf('date');
        const amountIndex = header.indexOf('amount');
        const categoryIndex = header.indexOf('category');
        const subCategoryIndex = header.indexOf('subcategory');
        const typeIndex = header.indexOf('type');

        if (amountIndex === -1) {
            throw new Error("CSV must contain an 'amount' column.");
        }

        const newTransactions: Omit<Transaction, 'id'>[] = [];
        let updatedCategories = [...categories];

        for (let i = 1; i < lines.length; i++) {
            const data = lines[i].split(',');
            const amount = parseFloat(data[amountIndex]);
            if (isNaN(amount)) continue;

            let categoryName = data[categoryIndex]?.trim() || 'Other';
            let subCategoryName = data[subCategoryIndex]?.trim() || '';

            let categoryExists = updatedCategories.find(c => c.name.toLowerCase() === categoryName.toLowerCase());
            if (!categoryExists) {
                const newCategory: Category = { id: `cat-${Date.now()}-${i}`, name: categoryName, icon: 'Other', subCategories: [] };
                updatedCategories.push(newCategory);
                categoryExists = newCategory;
            } else {
                 categoryName = categoryExists.name;
            }
            
            if (subCategoryName && !categoryExists.subCategories.find(s => s.toLowerCase() === subCategoryName.toLowerCase())) {
                 updatedCategories = updatedCategories.map(c => c.id === categoryExists!.id ? { ...c, subCategories: [...c.subCategories, subCategoryName].sort() } : c);
            }

            const dateStr = data[dateIndex]?.trim();
            let transactionDate: string;
            if (dateStr && !isNaN(new Date(dateStr).getTime())) {
                transactionDate = new Date(dateStr).toISOString();
            } else {
                const yesterday = new Date();
                yesterday.setDate(yesterday.getDate() - 1);
                transactionDate = yesterday.toISOString();
            }

            newTransactions.push({
                amount: Math.abs(amount),
                category: categoryName,
                subCategory: subCategoryName,
                date: transactionDate,
                type: (data[typeIndex]?.trim().toLowerCase() === 'income') ? 'income' : 'expense',
                notes: `Imported on ${new Date().toLocaleDateString()}`,
            });
        }
        
        setCategories(updatedCategories);
        addTransactions(newTransactions);
        setImportStatus({type: 'success', message: t('importSuccess').replace('{count}', newTransactions.length.toString())});
    } catch(error) {
        console.error("CSV Import Error:", error);
        setImportStatus({type: 'error', message: t('importError')});
    } finally {
        setIsProcessing(false);
    }
  };

  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        const content = e.target?.result as string;
        parseAndImportCsv(content);
    };
    reader.readAsText(file);
    event.target.value = ''; // Reset file input
  }

  return (
    <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg animate-fade-in max-w-lg mx-auto">
        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200 mb-2">{t('importData')}</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">{t('importInstructions')}</p>
        <div className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg p-8 text-center">
            <input type="file" id="csv-importer" accept=".csv" onChange={handleFileImport} className="hidden" disabled={isProcessing} />
            <label htmlFor="csv-importer" className="w-full cursor-pointer inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 disabled:opacity-50">
                {isProcessing ? t('processing') : t('importFromCsv')}
            </label>
        </div>
        {importStatus && <p className={`mt-4 text-sm text-center ${importStatus.type === 'success' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>{importStatus.message}</p>}
    </div>
  );
};

export default Import;