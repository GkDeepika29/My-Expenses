import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { INITIAL_CATEGORIES, INITIAL_PAYMENT_METHODS, LANGUAGES, CURRENCIES, InitialCategory } from '../constants';
import { Category, Language, Currency } from '../types';
import { CategoryIcon, ImportIcon } from './icons';

interface OnboardingModalProps {
    onClose: (config: { categories: Category[], paymentMethods: string[], currency: Currency }) => void;
}

const OnboardingModal: React.FC<OnboardingModalProps> = ({ onClose }) => {
    const { t, language, setLanguage } = useLanguage();
    const [step, setStep] = useState(0);
    
    const [selectedCurrency, setSelectedCurrency] = useState<Currency>('INR');

    const [selectedCategories, setSelectedCategories] = useState<Record<string, boolean>>(
        INITIAL_CATEGORIES.reduce((acc, cat) => ({...acc, [cat.id]: true}), {})
    );

    const [finalCategories, setFinalCategories] = useState<Category[]>([]);

    const [selectedPaymentMethods, setSelectedPaymentMethods] = useState<Record<string, boolean>>(
        INITIAL_PAYMENT_METHODS.reduce((acc, methodKey) => ({...acc, [methodKey]: true}), {})
    );

    const handleCategoryToggle = (catId: string) => {
        setSelectedCategories(prev => ({ ...prev, [catId]: !prev[catId] }));
    };
    
    const handleSubCategoryToggle = (catId: string, subCategory: string) => {
        setFinalCategories(prev => prev.map(cat => {
            if (cat.id === catId) {
                const subExists = cat.subCategories.includes(subCategory);
                return {
                    ...cat,
                    subCategories: subExists
                        ? cat.subCategories.filter(s => s !== subCategory)
                        : [...cat.subCategories, subCategory]
                };
            }
            return cat;
        }));
    };

    const handlePaymentMethodToggle = (methodKey: string) => {
        setSelectedPaymentMethods(prev => ({...prev, [methodKey]: !prev[methodKey] }));
    }

    const translateInitialConfig = (initialConfig: InitialCategory[]): Category[] => {
        return initialConfig.map(cat => ({
            id: cat.id,
            name: t(cat.nameKey),
            icon: cat.icon,
            subCategories: cat.subCategoriesKeys.map(key => t(key)),
        }));
    };

    const handleNext = () => {
        if (step === 4) { // Category selection is now step 4
             const userInitialCategories = INITIAL_CATEGORIES.filter(c => selectedCategories[c.id]);
             const userTranslatedCategories = translateInitialConfig(userInitialCategories);
             setFinalCategories(userTranslatedCategories);
        }
        setStep(prev => prev + 1);
    }
    
    const handleBack = () => {
        setStep(prev => prev - 1);
    }

    const handleFinish = () => {
        const userPaymentMethods = Object.keys(selectedPaymentMethods).filter(m => selectedPaymentMethods[m]);
        onClose({ categories: finalCategories, paymentMethods: userPaymentMethods, currency: selectedCurrency });
    }

    const renderStep = () => {
        switch (step) {
            case 0: // Welcome Slogan
                return (
                    <div className="animate-fade-in text-center">
                        <h2 className="text-3xl font-bold text-indigo-600 dark:text-indigo-400 mb-4">{t('onboardingSlogan')}</h2>
                        <p className="text-slate-600 dark:text-slate-300">{t('onboardingWelcome')}</p>
                    </div>
                );
            case 1: // Language Selection
                return (
                    <div className="animate-fade-in text-center">
                         <h2 className="text-xl font-bold text-indigo-600 dark:text-indigo-400 mb-4">{t('selectYourLanguage')}</h2>
                         <div className="space-y-2 max-h-72 overflow-y-auto pr-2">
                            {LANGUAGES.map(lang => (
                                <button
                                    key={lang.id}
                                    onClick={() => { setLanguage(lang.id as Language); handleNext(); }}
                                    className={`w-full text-left p-3 rounded-lg border-2 transition-colors bg-slate-100 dark:bg-slate-700 border-transparent hover:border-indigo-500`}
                                >
                                    {lang.name}
                                </button>
                            ))}
                         </div>
                    </div>
                );
            case 2: // Personalization Intro
                return (
                     <div className="animate-fade-in text-center">
                        <h3 className="text-xl font-bold text-indigo-600 dark:text-indigo-400 mb-2">{t('onboardingPersonalizeIntro')}</h3>
                        <p className="text-slate-600 dark:text-slate-300">{t('onboardingPersonalize')}</p>
                    </div>
                );
            case 3: // Feature Preview
                return (
                     <div className="animate-fade-in">
                        <h3 className="text-xl font-bold text-center mb-4">{t('onboardingFeaturePreview')}</h3>
                        <div className="bg-slate-100 dark:bg-slate-700 p-4 rounded-lg flex items-center space-x-4">
                            <ImportIcon className="w-10 h-10 text-indigo-500 flex-shrink-0" />
                            <p className="text-sm text-slate-700 dark:text-slate-300">{t('onboardingFeatureCsv')}</p>
                        </div>
                    </div>
                );
            case 4: // Currency Selection
                return (
                    <div className="animate-fade-in">
                        <h3 className="text-xl font-bold mb-1">{t('currencySetup')}</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">{t('currencySetupDesc')}</p>
                        <div className="space-y-2 max-h-64 overflow-y-auto pr-2">
                            {CURRENCIES.map(curr => (
                                <button key={curr.id} onClick={() => setSelectedCurrency(curr.id)} className={`w-full text-left p-3 rounded-lg border-2 transition-colors ${selectedCurrency === curr.id ? 'bg-indigo-100 dark:bg-indigo-900/50 border-indigo-500' : 'bg-slate-100 dark:bg-slate-700 border-transparent'}`}>
                                    <span className="font-medium">{curr.name} ({curr.symbol})</span>
                                </button>
                            ))}
                        </div>
                    </div>
                );
            case 5: // Category Selection
                return (
                    <div className="animate-fade-in">
                        <h3 className="text-xl font-bold mb-1">{t('categorySetup')}</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">{t('categorySetupDesc')}</p>
                        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 max-h-64 overflow-y-auto pr-2">
                           {INITIAL_CATEGORIES.map(cat => (
                               <button key={cat.id} onClick={() => handleCategoryToggle(cat.id)} className={`flex flex-col items-center justify-center p-3 rounded-lg border-2 transition-all duration-200 ${selectedCategories[cat.id] ? 'bg-indigo-100 dark:bg-indigo-900/50 border-indigo-500 scale-105' : 'bg-slate-100 dark:bg-slate-700 border-transparent'}`}>
                                   <CategoryIcon name={cat.icon} className="w-10 h-10 mb-1"/>
                                   <span className="text-xs font-medium text-center">{t(cat.nameKey)}</span>
                               </button>
                           ))}
                        </div>
                    </div>
                );
            case 6: // Sub-category Selection
                 return (
                    <div className="animate-fade-in">
                        <h3 className="text-xl font-bold mb-1">{t('subCategorySetup')}</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">{t('subCategorySetupDesc')}</p>
                        <div className="space-y-3 max-h-64 overflow-y-auto pr-2">
                           {finalCategories.map(cat => {
                                const initialCat = INITIAL_CATEGORIES.find(c => c.id === cat.id);
                                if (!initialCat || initialCat.subCategoriesKeys.length === 0) return null;
                               
                                return (
                                   <div key={cat.id}>
                                       <h4 className="font-semibold mb-1 flex items-center space-x-2"><CategoryIcon name={cat.icon} className="w-5 h-5" /><span>{cat.name}</span></h4>
                                       <div className="flex flex-wrap gap-2">
                                           {initialCat.subCategoriesKeys.map(subKey => (
                                               <button key={subKey} onClick={() => handleSubCategoryToggle(cat.id, t(subKey))} className={`px-3 py-1 rounded-full text-sm transition-colors ${cat.subCategories.includes(t(subKey)) ? 'bg-indigo-500 text-white' : 'bg-slate-200 dark:bg-slate-600'}`}>
                                                   {t(subKey)}
                                               </button>
                                           ))}
                                       </div>
                                   </div>
                               );
                           })}
                        </div>
                    </div>
                );
            case 7: // Payment Method Selection
                 return (
                    <div className="animate-fade-in">
                        <h3 className="text-xl font-bold mb-1">{t('paymentSetup')}</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">{t('paymentSetupDesc')}</p>
                        <div className="space-y-2 max-h-64 overflow-y-auto pr-2">
                            {INITIAL_PAYMENT_METHODS.map(methodKey => (
                                <button key={methodKey} onClick={() => handlePaymentMethodToggle(methodKey)} className={`w-full text-left p-3 rounded-lg border-2 transition-colors ${selectedPaymentMethods[methodKey] ? 'bg-indigo-100 dark:bg-indigo-900/50 border-indigo-500' : 'bg-slate-100 dark:bg-slate-700 border-transparent'}`}>
                                    <span className="font-medium">{t(methodKey)}</span>
                                </button>
                            ))}
                        </div>
                    </div>
                );
            case 8: // Finish
                return (
                     <div className="animate-fade-in text-center">
                        <h3 className="text-2xl font-bold text-indigo-600 dark:text-indigo-400 mb-2">{t('allSet')}</h3>
                        <p className="text-slate-600 dark:text-slate-300">{t('onboardingComplete')}</p>
                    </div>
                )
            default: return null;
        }
    }

    const totalSteps = 8;
    const progress = (step / totalSteps) * 100;

    return (
        <div className="fixed inset-0 bg-slate-900 bg-opacity-80 flex items-center justify-center z-50 animate-fade-in-fast">
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl p-6 w-full max-w-sm m-4">
                 {step > 1 && step < totalSteps && (
                    <div className="text-center mb-4">
                        <h2 className="text-2xl font-bold">{t('welcome')}</h2>
                        <p className="text-slate-600 dark:text-slate-300 text-sm">{t('onboardingIntro')}</p>
                    </div>
                 )}

                {step > 1 && step < totalSteps && <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2 mb-6">
                    <div className="bg-indigo-600 h-2 rounded-full transition-all duration-500" style={{ width: `${progress}%` }}></div>
                </div>}

                <div className="min-h-[20rem] flex flex-col justify-center">
                    {renderStep()}
                </div>

                <div className="mt-6 flex items-center space-x-2">
                   {step > 1 && step < totalSteps && (
                       <button onClick={handleBack} className="px-4 py-3 text-lg font-medium text-slate-700 dark:text-slate-200 bg-slate-200 dark:bg-slate-600 rounded-md hover:bg-slate-300 dark:hover:bg-slate-500">
                           {t('back')}
                       </button>
                   )}
                   {step < totalSteps && step !== 1 && (
                       <button onClick={step === 0 ? () => setStep(1) : handleNext} className="w-full px-4 py-3 text-lg font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700">
                          {step === 0 ? t('getStarted') : t('next')}
                       </button>
                   )}
                   {step === totalSteps && (
                        <button onClick={handleFinish} className="w-full px-4 py-3 text-lg font-medium text-white bg-green-600 rounded-md hover:bg-green-700">
                           {t('finish')}
                        </button>
                   )}
                </div>
            </div>
        </div>
    );
};

export default OnboardingModal;