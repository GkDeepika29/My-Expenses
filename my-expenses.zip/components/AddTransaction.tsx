import React, { useState, useRef, useMemo } from 'react';
import { Transaction, TransactionType, Currency, RecurringTransaction, RecurringFrequency, Category } from '../types';
import { parseTransactionFromText, parseTransactionFromImage } from '../services/geminiService';
import { MicIcon, CameraIcon, SpinnerIcon, CategoryIcon } from './icons';
import { useLanguage } from '../context/LanguageContext';
import { formatCurrency } from '../utils/currency';
import { calculateNextDueDate } from '../utils/recurring';

interface AddTransactionProps {
  onTransactionAdded: (transaction: Omit<Transaction, 'id'> | Omit<Transaction, 'id'>[]) => void;
  onRecurringTransactionAdded: (recurring: Omit<RecurringTransaction, 'id'>, addFirst: boolean) => void;
  aiConsent: boolean;
  categories: Category[];
  currency: Currency;
  paymentMethods: string[];
}

const WEEK_DAYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];

const AddTransaction: React.FC<AddTransactionProps> = ({ onTransactionAdded, onRecurringTransactionAdded, aiConsent, categories, currency, paymentMethods }) => {
  const [type, setType] = useState<TransactionType>('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [subCategory, setSubCategory] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');
  
  const [isRecurring, setIsRecurring] = useState(false);
  const [frequency, setFrequency] = useState<RecurringFrequency>('monthly');
  const [daysOfWeek, setDaysOfWeek] = useState<number[]>([]);
  const [dayOfMonth, setDayOfMonth] = useState<number>(1);
  
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const { t, language } = useLanguage();

  const availableSubcategories = useMemo(() => {
    const selectedCat = categories.find(c => c.name === category);
    return selectedCat?.subCategories || [];
  }, [category, categories]);

  const resetForm = () => {
    setAmount('');
    setCategory('');
    setSubCategory('');
    setPaymentMethod('');
    setNotes('');
    setDate(new Date().toISOString().split('T')[0]);
    setIsRecurring(false);
    setDaysOfWeek([]);
    setDayOfMonth(1);
  };
  
  const showStatus = (type: 'success' | 'error' | 'info', textKey: string, duration: number = 3000) => {
    setStatusMessage({ type, text: t(textKey) });
    if(duration > 0) {
      setTimeout(() => setStatusMessage(null), duration);
    }
  };

  const handleDayOfWeekToggle = (dayIndex: number) => {
    setDaysOfWeek(prev => 
      prev.includes(dayIndex) ? prev.filter(d => d !== dayIndex) : [...prev, dayIndex].sort()
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !category || !date) {
      showStatus('error', 'errorAdding');
      return;
    }
    if (frequency === 'custom_weekly' && daysOfWeek.length === 0) {
        alert('Please select at least one day for the custom weekly schedule.');
        return;
    }

    if (isRecurring) {
        const recurringData: Omit<RecurringTransaction, 'id' | 'nextDueDate'> = {
            type,
            amount: parseFloat(amount),
            category,
            subCategory,
            paymentMethod,
            notes,
            frequency,
            startDate: date,
            ...(frequency === 'custom_weekly' && { daysOfWeek }),
            ...(frequency === 'custom_monthly' && { dayOfMonth }),
        };
        const nextDueDate = calculateNextDueDate(date, recurringData.frequency, { daysOfWeek, dayOfMonth });

        onRecurringTransactionAdded({
            ...recurringData,
            nextDueDate: nextDueDate.toISOString(),
        }, true);

    } else {
        onTransactionAdded({
            type,
            amount: parseFloat(amount),
            category,
            subCategory,
            paymentMethod,
            date,
            notes,
        });
    }

    resetForm();
    showStatus('success', 'transactionAdded');
  };
  
  const handleUnitClick = (multiplier: number) => {
    const currentAmount = parseFloat(amount) || 0;
    if (currentAmount > 0) {
        setAmount(String(currentAmount * multiplier));
    }
  };

  const populateForm = (data: { type?: TransactionType, amount?: number; category?: string; notes?: string }) => {
    if (data.type) setType(data.type);
    if (data.amount) setAmount(data.amount.toString());
    if (data.category && categories.some(c => c.name === data.category)) setCategory(data.category);
    if (data.notes) setNotes(data.notes);
  };

  const handleVoiceInput = () => {
    if (!aiConsent) { alert(t('aiConsentPrompt')); return; }
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) { alert("Speech recognition not supported."); return; }

    const recognition = new SpeechRecognition();
    recognition.lang = language;
    recognition.onstart = () => { setIsProcessing(true); showStatus('info', 'listening', 0); };
    recognition.onresult = async (event) => {
      const speechResult = event.results[0][0].transcript;
      showStatus('info', 'processing', 0);
      try {
        const parsedData = await parseTransactionFromText(speechResult, language, categories);
        populateForm(parsedData);
      } catch (error) { showStatus('error', 'errorParsing'); } 
      finally { setIsProcessing(false); setStatusMessage(null); }
    };
    recognition.onerror = () => { showStatus('error', 'errorParsing'); setIsProcessing(false); };
    recognition.onend = () => { if(isProcessing) { setIsProcessing(false); setStatusMessage(null); } };
    recognition.start();
  };
  
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !aiConsent) { if (!aiConsent) alert(t('aiConsentPrompt')); return; }
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64String = (reader.result as string).split(',')[1];
      setIsProcessing(true);
      showStatus('info', 'processing', 0);
      try {
        const parsedData = await parseTransactionFromImage(base64String, file.type, categories);
        populateForm(parsedData);
      } catch (error) { showStatus('error', 'errorParsing'); } 
      finally { setIsProcessing(false); setStatusMessage(null); }
    };
    reader.readAsDataURL(file);
    if (fileInputRef.current) { fileInputRef.current.value = ""; }
  };

  return (
    <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg animate-fade-in">
      <form onSubmit={handleSubmit} className="space-y-6">
        <fieldset>
          <legend className="text-lg font-medium text-slate-800 dark:text-slate-200 mb-2">{t('transactionDetails')}</legend>
          <div className="space-y-4">
             <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{t('transactionType')}</label>
                <div className="grid grid-cols-2 gap-2 rounded-lg bg-slate-100 dark:bg-slate-700 p-1">
                    <button type="button" onClick={() => setType('expense')} className={`px-4 py-2 text-sm font-medium rounded-md transition-shadow ${type === 'expense' ? 'bg-white dark:bg-slate-500 shadow text-indigo-700 dark:text-white' : 'text-slate-600 dark:text-slate-300'}`}>{t('expense')}</button>
                    <button type="button" onClick={() => setType('income')} className={`px-4 py-2 text-sm font-medium rounded-md transition-shadow ${type === 'income' ? 'bg-white dark:bg-slate-500 shadow text-indigo-700 dark:text-white' : 'text-slate-600 dark:text-slate-300'}`}>{t('income')}</button>
                </div>
            </div>
            <div>
              <label htmlFor="amount" className="block text-sm font-medium text-slate-700 dark:text-slate-300">{t('amount')} ({formatCurrency(0, currency, language, 0).replace(/[0-9.,]/g, '')})</label>
              <div className="mt-1 flex rounded-md shadow-sm">
                 <input type="number" id="amount" value={amount} onChange={e => setAmount(e.target.value)} required step="0.01" className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-l-md placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
                 <button type="button" onClick={() => handleUnitClick(1000)} className="px-3 py-2 bg-slate-100 dark:bg-slate-600 text-slate-600 dark:text-slate-200 border border-l-0 border-slate-300 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-500 font-bold">{t('thousand')}</button>
                 <button type="button" onClick={() => handleUnitClick(100000)} className="px-3 py-2 bg-slate-100 dark:bg-slate-600 text-slate-600 dark:text-slate-200 border border-l-0 border-slate-300 dark:border-slate-600 rounded-r-md hover:bg-slate-200 dark:hover:bg-slate-500 font-bold">{t('lakh')}</button>
              </div>
            </div>
            <div>
              <label htmlFor="category" className="block text-sm font-medium text-slate-700 dark:text-slate-300">{t('category')}</label>
              <select id="category" value={category} onChange={e => {setCategory(e.target.value); setSubCategory('')}} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                <option value="" disabled>{t('selectCategory')}</option>
                {categories.map(cat => <option key={cat.id} value={cat.name}>{cat.name}</option>)}
              </select>
            </div>
            {availableSubcategories.length > 0 && (
                 <div>
                    <label htmlFor="subCategory" className="block text-sm font-medium text-slate-700 dark:text-slate-300">{t('subCategory')}</label>
                    <select id="subCategory" value={subCategory} onChange={e => setSubCategory(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                      <option value="">{t('selectSubCategory')}</option>
                      {availableSubcategories.map(sub => <option key={sub} value={sub}>{sub}</option>)}
                    </select>
                  </div>
            )}
             <div>
              <label htmlFor="paymentMethod" className="block text-sm font-medium text-slate-700 dark:text-slate-300">{t('paymentMethod')}</label>
              <select id="paymentMethod" value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                <option value="">{t('selectPaymentMethod')}</option>
                {paymentMethods.map(method => <option key={method} value={method}>{t(method)}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor="date" className="block text-sm font-medium text-slate-700 dark:text-slate-300">{t(isRecurring ? 'startDate' : 'date')}</label>
              <input type="date" id="date" value={date} onChange={e => setDate(e.target.value)} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
            </div>
            <div>
              <label htmlFor="notes" className="block text-sm font-medium text-slate-700 dark:text-slate-300">{t('notes')}</label>
              <input type="text" id="notes" value={notes} onChange={e => setNotes(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
            </div>
          </div>
        </fieldset>

        <fieldset className="space-y-4">
            <div className="relative flex items-start"><div className="flex h-5 items-center"><input id="recurring" type="checkbox" checked={isRecurring} onChange={(e) => setIsRecurring(e.target.checked)} className="h-4 w-4 rounded border-gray-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500 bg-transparent dark:bg-slate-900" /></div><div className="ml-3 text-sm"><label htmlFor="recurring" className="font-medium text-gray-700 dark:text-slate-300">{t('makeRecurring')}</label></div></div>
            {isRecurring && (
                <div className="space-y-4 animate-fade-in-fast">
                    <div>
                        <label htmlFor="frequency" className="block text-sm font-medium text-slate-700 dark:text-slate-300">{t('frequency')}</label>
                        <select id="frequency" value={frequency} onChange={e => setFrequency(e.target.value as RecurringFrequency)} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <option value="daily">{t('daily')}</option>
                            <option value="weekdays">{t('weekdays')}</option>
                            <option value="custom_weekly">{t('custom_weekly')}</option>
                            <option value="weekly">{t('weekly')}</option>
                            <option value="custom_monthly">{t('custom_monthly')}</option>
                            <option value="monthly">{t('monthly')}</option>
                            <option value="last_weekday_monthly">{t('last_weekday_monthly')}</option>
                        </select>
                    </div>
                    {frequency === 'custom_weekly' && (<div className="animate-fade-in-fast"><div className="grid grid-cols-7 gap-1 rounded-lg bg-slate-100 dark:bg-slate-700 p-1">{WEEK_DAYS.map((day, index) => (<button type="button" key={day} onClick={() => handleDayOfWeekToggle(index)} className={`px-2 py-2 text-xs font-bold rounded ${daysOfWeek.includes(index) ? 'bg-indigo-600 text-white shadow' : 'bg-white dark:bg-slate-500 text-slate-700 dark:text-white'}`}>{t(day)}</button>))}</div></div>)}
                    {frequency === 'custom_monthly' && (<div className="animate-fade-in-fast space-y-2"><label htmlFor="dayOfMonth" className="block text-sm font-medium text-slate-700 dark:text-slate-300">{t('dayOfMonth')}</label><div className="flex items-center gap-4"><input type="number" id="dayOfMonth" value={dayOfMonth === -1 ? '' : dayOfMonth} onChange={e => setDayOfMonth(parseInt(e.target.value) || 1)} min="1" max="31" disabled={dayOfMonth === -1} className="block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm disabled:bg-slate-200 dark:disabled:bg-slate-600" /><div className="flex items-center"><input id="lastDay" type="checkbox" checked={dayOfMonth === -1} onChange={(e) => setDayOfMonth(e.target.checked ? -1 : 1)} className="h-4 w-4 rounded border-gray-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500" /><label htmlFor="lastDay" className="ml-2 block text-sm text-gray-900 dark:text-slate-300">{t('lastDayOfMonth')}</label></div></div></div>)}
                </div>
            )}
        </fieldset>

        <fieldset className="space-y-3 pt-2">
            <legend className="sr-only">Actions</legend>
             <div className="flex space-x-2">
                <button type="button" onClick={handleVoiceInput} disabled={isProcessing || !aiConsent} className="flex-1 inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-sky-600 hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500 disabled:bg-slate-400 dark:disabled:bg-slate-600"><MicIcon /><span className="ml-2">{t('useVoice')}</span></button>
                <button type="button" onClick={() => fileInputRef.current?.click()} disabled={isProcessing || !aiConsent} className="flex-1 inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 disabled:bg-slate-400 dark:disabled:bg-slate-600"><CameraIcon /><span className="ml-2">{t('scanReceipt')}</span></button>
                <input type="file" accept="image/*" capture="environment" ref={fileInputRef} onChange={handleImageUpload} className="hidden" />
            </div>
            <button type="submit" disabled={isProcessing} className="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-slate-400 dark:disabled:bg-slate-600">{t('addTransactionButton')}</button>
            {statusMessage && (<div className={`p-3 rounded-md text-sm text-center ${statusMessage.type === 'success' ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-300' : statusMessage.type === 'error' ? 'bg-red-100 dark:bg-red-900/50 text-red-800 dark:text-red-300' : 'bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-300'}`}>{statusMessage.text}</div>)}
        </fieldset>
      </form>
    </div>
  );
};

export default AddTransaction;