import React, { useMemo, useState, useEffect } from 'react';
import { Transaction, Currency, Category, Budget, Language, ALL_LANGUAGES } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend, LineChart, Line, XAxis, YAxis, CartesianGrid, BarChart, Bar, Tooltip } from 'recharts';
import { useLanguage } from '../context/LanguageContext';
import { formatCurrency } from '../utils/currency';
import { translations } from '../translations';
import { INITIAL_CATEGORIES } from '../constants';
import { useTheme } from '../context/ThemeContext';
import { ChevronLeftIcon, ChevronRightIcon } from './icons';

interface DashboardProps {
  transactions: Transaction[];
  currency: Currency;
  categories: Category[];
  budgets: Budget;
}

type GroupBy = 'Category' | 'Subcategory' | 'Payment Method';
const GROUP_BY_OPTIONS: { key: GroupBy, labelKey: string }[] = [
    { key: 'Category', labelKey: 'byCategory' },
    { key: 'Subcategory', labelKey: 'bySubcategory' },
    { key: 'Payment Method', labelKey: 'byPaymentMethod' }
];
const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#F97316'];
const MONTHS_TO_SHOW_OPTIONS = [3, 6, 12];

const itemKeyMap = new Map<string, string>();
INITIAL_CATEGORIES.forEach(cat => {
    ALL_LANGUAGES.forEach(lang => {
        const translatedName = translations[cat.nameKey]?.[lang];
        if (translatedName) itemKeyMap.set(translatedName, cat.nameKey);
    });
    cat.subCategoriesKeys.forEach(subKey => {
        ALL_LANGUAGES.forEach(lang => {
            const translatedName = translations[subKey]?.[lang];
            if (translatedName) itemKeyMap.set(translatedName, subKey);
        });
    });
});


const Dashboard: React.FC<DashboardProps> = ({ transactions, currency, categories, budgets }) => {
  const { t, language } = useLanguage();
  const { theme } = useTheme();

  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [pieDrilldown, setPieDrilldown] = useState<string | null>(null);

  const [lineChartGroupBy, setLineChartGroupBy] = useState<GroupBy>('Category');
  const [lineChartSelection, setLineChartSelection] = useState<string[]>([]);
  
  const [barChartMonths, setBarChartMonths] = useState(3);
  const [barChartGroupBy, setBarChartGroupBy] = useState<GroupBy>('Category');
  
  useEffect(() => setLineChartSelection([]), [lineChartGroupBy]);
  useEffect(() => setPieDrilldown(null), [currentMonth]);

  const changeMonth = (offset: number) => {
    const newDate = new Date(currentMonth);
    newDate.setMonth(newDate.getMonth() + offset, 15); // Use day 15 to avoid month-end issues
    setCurrentMonth(newDate);
  };

  const { filteredTransactions, categoryMap } = useMemo(() => {
    const startOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1);
    const endOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0);
    startOfMonth.setUTCHours(0, 0, 0, 0);
    endOfMonth.setUTCHours(23, 59, 59, 999);
    
    const filtered = transactions.filter(tx => {
      const txDate = new Date(tx.date);
      return txDate >= startOfMonth && txDate <= endOfMonth;
    });

    const catMap = new Map(categories.map(c => [c.name, c]));

    return { filteredTransactions: filtered, categoryMap: catMap };
  }, [transactions, currentMonth, categories]);

  const { totalIncome, totalExpenses } = useMemo(() => {
    return filteredTransactions.reduce((acc, tx) => {
        if (tx.type === 'income') {
            acc.totalIncome += tx.amount;
        } else {
            acc.totalExpenses += tx.amount;
        }
        return acc;
    }, { totalIncome: 0, totalExpenses: 0 });
  }, [filteredTransactions]);
  
  const savings = totalIncome - totalExpenses;
  
  const highlights = useMemo(() => {
    const expenseTxs = filteredTransactions.filter(tx => tx.type === 'expense');
    if (expenseTxs.length === 0) return {};
    
    const spendingByDay = expenseTxs.reduce((acc, tx) => {
        const day = tx.date.split('T')[0];
        acc[day] = (acc[day] || 0) + tx.amount;
        return acc;
    }, {} as {[key: string]: number});
    const topDay = Object.entries(spendingByDay).sort((a,b) => b[1] - a[1])[0];
    
    const countMap = (key: 'category' | 'subCategory' | 'paymentMethod') => expenseTxs.reduce((acc, tx) => {
        const item = tx[key];
        if(item) {
            acc[item] = (acc[item] || 0) + tx.amount;
        }
        return acc;
    }, {} as {[key: string]: number});

    const topCategory = Object.entries(countMap('category')).sort((a,b) => b[1] - a[1])[0];
    const topSubCategory = Object.entries(countMap('subCategory')).sort((a,b) => b[1] - a[1])[0];
    const topPayment = Object.entries(countMap('paymentMethod')).sort((a,b) => b[1] - a[1])[0];

    return { topDay, topCategory, topSubCategory, topPayment };
  }, [filteredTransactions]);

  const pieChartData = useMemo(() => {
    const expenseTxs = filteredTransactions.filter(tx => tx.type === 'expense');
    const totalExpenses = expenseTxs.reduce((sum, tx) => sum + tx.amount, 0);
    
    if (pieDrilldown) { // Subcategory view
        const parentCategory = categoryMap.get(pieDrilldown);
        if (!parentCategory) return { data: [], total: 0 };
        const categoryExpenses = expenseTxs.filter(tx => tx.category === pieDrilldown);
        const total = categoryExpenses.reduce((sum, tx) => sum + tx.amount, 0);
        
        const dataMap: { [key: string]: number } = {};
        categoryExpenses.forEach(tx => {
            const key = tx.subCategory || 'Uncategorized';
            dataMap[key] = (dataMap[key] || 0) + tx.amount;
        });

        return { 
            data: Object.entries(dataMap).map(([name, value]) => ({ 
                name, 
                value,
                budget: budgets[`${parentCategory.id}-${name}`] || 0
            })).sort((a,b) => b.value - a.value),
            total
        };
    } else { // Category view
        const dataMap: { [key: string]: number } = {};
        expenseTxs.forEach(tx => {
            const key = tx.category;
            dataMap[key] = (dataMap[key] || 0) + tx.amount;
        });
        
        return { 
            data: Object.entries(dataMap).map(([name, value]) => ({ 
                name, 
                value,
                budget: budgets[categoryMap.get(name)?.id || ''] || 0
            })).sort((a,b) => b.value - a.value),
            total: totalExpenses
        };
    }
  }, [filteredTransactions, pieDrilldown, categoryMap, budgets]);
  
  const lineChartData = useMemo(() => {
    const expenseTxs = filteredTransactions.filter(tx => tx.type === 'expense');
    const lineDataMap: { [date: string]: { [key: string]: number } } = {};
    const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate();
    for (let i = 1; i <= daysInMonth; i++) {
        const date = new Date(Date.UTC(currentMonth.getFullYear(), currentMonth.getMonth(), i));
        lineDataMap[date.toISOString().split('T')[0]] = {};
    }
    
    expenseTxs.forEach(tx => {
        const day = tx.date.split('T')[0];
        let rawKey: string | undefined;
        switch(lineChartGroupBy) {
            case 'Category': rawKey = tx.category; break;
            case 'Subcategory': rawKey = tx.subCategory; break;
            case 'Payment Method': rawKey = tx.paymentMethod; break;
        }
        if (rawKey && lineChartSelection.includes(rawKey)) {
             lineDataMap[day][rawKey] = (lineDataMap[day][rawKey] || 0) + tx.amount;
        }
    });

    return Object.entries(lineDataMap).map(([date, values]) => ({ date, ...values })).sort((a,b) => a.date.localeCompare(b.date));
  }, [filteredTransactions, lineChartGroupBy, lineChartSelection, currentMonth]);

  const barChartData = useMemo(() => {
    const data: { name: string, [key: string]: number | string }[] = [];
    for (let i = 0; i < barChartMonths; i++) {
        const date = new Date(currentMonth);
        date.setMonth(currentMonth.getMonth() - i);
        const monthName = date.toLocaleDateString(language, { month: 'short', year: 'numeric'});
        
        const start = new Date(date.getFullYear(), date.getMonth(), 1);
        const end = new Date(date.getFullYear(), date.getMonth() + 1, 0);

        const monthTxs = transactions.filter(tx => {
            const txDate = new Date(tx.date);
            return tx.type === 'expense' && txDate >= start && txDate <= end;
        });

        const grouped: {[key: string]: number} = {};
        monthTxs.forEach(tx => {
            let rawKey: string | undefined;
            switch(barChartGroupBy) {
                case 'Category': rawKey = tx.category; break;
                case 'Subcategory': rawKey = tx.subCategory ? `${tx.category} > ${tx.subCategory}` : undefined; break;
                case 'Payment Method': rawKey = tx.paymentMethod; break;
            }
            if(rawKey) {
                grouped[rawKey] = (grouped[rawKey] || 0) + tx.amount;
            }
        });

        const top3 = Object.entries(grouped).sort((a,b) => b[1] - a[1]).slice(0, 3);
        const monthData: { name: string, [key: string]: number | string } = { name: monthName };
        let otherTotal = monthTxs.reduce((sum, tx) => sum + tx.amount, 0);
        top3.forEach(item => {
            monthData[item[0]] = item[1];
            otherTotal -= item[1];
        });
        if(otherTotal > 0) monthData['Other'] = otherTotal;
        data.push(monthData);
    }
    return data.reverse();
  }, [transactions, barChartMonths, currentMonth, language, barChartGroupBy]);
  const barChartKeys = useMemo(() => [...new Set(barChartData.flatMap(d => Object.keys(d).filter(k => k !== 'name')))], [barChartData]);
  
  const tooltipStyle = { backgroundColor: theme === 'dark' ? '#1e293b' : '#ffffff', border: '1px solid', borderColor: theme === 'dark' ? '#334155' : '#e2e8f0', color: theme === 'dark' ? '#e2e8f0' : '#1e293b', borderRadius: '0.5rem', padding: '0.5rem' };
  
  return (
    <div className="space-y-6 animate-fade-in">
        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-lg flex items-center justify-between gap-2">
            <button onClick={() => changeMonth(-1)} className="p-2 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700"><ChevronLeftIcon /></button>
            <input 
                type="month"
                value={currentMonth.toISOString().substring(0, 7)}
                onChange={(e) => {
                    if(!e.target.value) return;
                    const [year, month] = e.target.value.split('-');
                    setCurrentMonth(new Date(parseInt(year), parseInt(month) - 1, 15));
                }}
                className="flex-grow px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm text-center"
            />
             <button onClick={() => changeMonth(1)} className="p-2 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700"><ChevronRightIcon /></button>
            <button onClick={() => setCurrentMonth(new Date())} className="px-3 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 whitespace-nowrap">
                {t('thisMonth')}
            </button>
        </div>

      {/* Income/Expense/Savings Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-100 dark:bg-green-900/50 p-4 rounded-xl shadow-lg">
            <h3 className="text-sm font-medium text-green-800 dark:text-green-200">{t('income')}</h3>
            <p className="text-2xl font-bold text-green-700 dark:text-green-300">{formatCurrency(totalIncome, currency, language)}</p>
        </div>
        <div className="bg-red-100 dark:bg-red-900/50 p-4 rounded-xl shadow-lg">
            <h3 className="text-sm font-medium text-red-800 dark:text-red-200">{t('expenses')}</h3>
            <p className="text-2xl font-bold text-red-700 dark:text-red-300">{formatCurrency(totalExpenses, currency, language)}</p>
        </div>
        <div className="bg-blue-100 dark:bg-blue-900/50 p-4 rounded-xl shadow-lg">
            <h3 className="text-sm font-medium text-blue-800 dark:text-blue-200">{t('savings')}</h3>
            <p className={`text-2xl font-bold ${savings >= 0 ? 'text-blue-700 dark:text-blue-300' : 'text-orange-600 dark:text-orange-400'}`}>
                {formatCurrency(savings, currency, language)}
            </p>
        </div>
      </div>

      {/* Monthly Highlights */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg">
        <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-200 mb-4">{t('monthlyHighlights')}</h2>
        {Object.keys(highlights).length > 0 && highlights.topDay ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div><p className="text-sm text-slate-500 dark:text-slate-400">{t('topSpendingDay')}</p><p className="font-bold text-indigo-600 dark:text-indigo-400">{new Date(highlights.topDay![0]).toLocaleDateString(language, {day:'numeric', month:'short', timeZone:'UTC'})}</p></div>
            <div><p className="text-sm text-slate-500 dark:text-slate-400">{t('topCategory')}</p><p className="font-bold text-indigo-600 dark:text-indigo-400 truncate">{highlights.topCategory![0]}</p></div>
            <div><p className="text-sm text-slate-500 dark:text-slate-400">{t('topSubCategory')}</p><p className="font-bold text-indigo-600 dark:text-indigo-400 truncate">{highlights.topSubCategory?.[0] || '-'}</p></div>
            <div><p className="text-sm text-slate-500 dark:text-slate-400">{t('topPaymentMethod')}</p><p className="font-bold text-indigo-600 dark:text-indigo-400 truncate">{highlights.topPayment?.[0] || '-'}</p></div>
        </div>
        ) : <p className="text-center text-slate-500 dark:text-slate-400 py-4">{t('noExpensesThisPeriod')}</p>}
      </div>
      
      {/* Pie Chart */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg">
          <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-200">{t('spendingBreakdown')}</h2>
              {pieDrilldown && <button onClick={() => setPieDrilldown(null)} className="text-sm text-indigo-600 dark:text-indigo-400 font-semibold hover:underline">{t('backToCategories')}</button>}
          </div>
          {pieChartData.data.length > 0 ? (
          <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                  <Pie data={pieChartData.data} cx="50%" cy="50%" labelLine={false} outerRadius={100} dataKey="value" nameKey="name" onClick={(data) => !pieDrilldown && setPieDrilldown(data.name)}>
                      {pieChartData.data.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} className={!pieDrilldown ? "cursor-pointer" : ""} />)}
                  </Pie>
                  <RechartsTooltip contentStyle={tooltipStyle} formatter={(value: number, name: string, props) => {
                      const { payload } = props;
                      const percentage = pieChartData.total > 0 ? (payload.value / pieChartData.total * 100).toFixed(1) : 0;
                      const budgetInfo = payload.budget > 0 ? `(${(payload.value / payload.budget * 100).toFixed(0)}% ${t('ofBudget')})` : '';
                      return [`${formatCurrency(value, currency, language)} (${percentage}% ${t('ofTotal')}) ${budgetInfo}`, name];
                  }} />
                  <Legend />
              </PieChart>
          </ResponsiveContainer>
          ) : <p className="text-center text-slate-500 dark:text-slate-400 py-10">{t('noExpensesThisPeriod')}</p>}
      </div>

      {/* Daily Spending Trend */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg">
          <div className="md:flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-200 mb-2 md:mb-0">{t('dailySpendingTrend')}</h2>
              <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{t('groupBy')}:</span>
                  <select value={lineChartGroupBy} onChange={e => setLineChartGroupBy(e.target.value as GroupBy)} className="px-2 py-1 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none text-sm">
                      {GROUP_BY_OPTIONS.map(opt => <option key={opt.key} value={opt.key}>{t(opt.labelKey)}</option>)}
                  </select>
              </div>
          </div>
          <div className="flex flex-wrap gap-2 mb-4">
              {pieChartData.data.map((item, index) => (
                  <button key={item.name} onClick={() => setLineChartSelection(prev => prev.includes(item.name) ? prev.filter(i => i !== item.name) : [...prev, item.name])} className={`px-3 py-1 text-sm font-medium rounded-full border-2 transition-colors ${lineChartSelection.includes(item.name) ? 'text-white' : ''}`} style={{ backgroundColor: lineChartSelection.includes(item.name) ? COLORS[index % COLORS.length] : 'transparent', borderColor: COLORS[index % COLORS.length], color: lineChartSelection.includes(item.name) ? 'white' : (theme === 'dark' ? '#e2e8f0' : '#1e293b') }}>
                      {item.name}
                  </button>
              ))}
          </div>
          <ResponsiveContainer width="100%" height={300}>
              <LineChart data={lineChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#334155' : '#e2e8f0'} />
                  <XAxis dataKey="date" tickFormatter={(d) => new Date(d).toLocaleDateString(language, {day:'numeric', timeZone:'UTC'})} stroke={theme === 'dark' ? '#94a3b8' : '#64748b'} />
                  <YAxis tickFormatter={(v) => formatCurrency(v, currency, language, 0)} stroke={theme === 'dark' ? '#94a3b8' : '#64748b'} width={80}/>
                  <Tooltip contentStyle={tooltipStyle} labelFormatter={(l) => new Date(l).toLocaleDateString(language, {weekday:'short', day:'numeric', month:'short', timeZone:'UTC'})} formatter={(v:number) => formatCurrency(v, currency, language)} />
                  <Legend />
                  {lineChartSelection.map((key, index) => (
                      <Line key={key} type="monotone" dataKey={key} stroke={COLORS[index % COLORS.length]} strokeWidth={2} dot={false} />
                  ))}
              </LineChart>
          </ResponsiveContainer>
      </div>
      
      {/* Month on Month */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg">
          <div className="md:flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-200 mb-2 md:mb-0">{t('monthOnMonth')}</h2>
              <div className="flex items-center gap-4">
                 <select value={barChartMonths} onChange={e => setBarChartMonths(Number(e.target.value))} className="px-2 py-1 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none text-sm">
                      {MONTHS_TO_SHOW_OPTIONS.map(opt => <option key={opt} value={opt}>{t('lastNMonths').replace('{count}', String(opt))}</option>)}
                  </select>
                  <select value={barChartGroupBy} onChange={e => setBarChartGroupBy(e.target.value as GroupBy)} className="px-2 py-1 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none text-sm">
                      {GROUP_BY_OPTIONS.map(opt => <option key={opt.key} value={opt.key}>{t(opt.labelKey)}</option>)}
                  </select>
              </div>
          </div>
          <ResponsiveContainer width="100%" height={300}>
              <BarChart data={barChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#334155' : '#e2e8f0'} />
                  <XAxis dataKey="name" stroke={theme === 'dark' ? '#94a3b8' : '#64748b'} />
                  <YAxis tickFormatter={(v) => formatCurrency(v, currency, language, 0)} stroke={theme === 'dark' ? '#94a3b8' : '#64748b'} width={80}/>
                  <Tooltip contentStyle={tooltipStyle} formatter={(v:number) => formatCurrency(v, currency, language)} cursor={{fill: theme === 'dark' ? 'rgba(148, 163, 184, 0.1)' : 'rgba(203, 213, 225, 0.3)'}} />
                  <Legend />
                  {barChartKeys.map((key, index) => <Bar key={key} dataKey={key} stackId="a" fill={COLORS[index % COLORS.length]} />)}
              </BarChart>
          </ResponsiveContainer>
      </div>

    </div>
  );
};

export default Dashboard;