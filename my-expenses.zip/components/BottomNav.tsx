import React from 'react';
import { Tab } from '../types';
import { TABS } from '../constants';
import { useLanguage } from '../context/LanguageContext';

interface BottomNavProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  const { t } = useLanguage();

  return (
    <nav className="sticky bottom-0 bg-white dark:bg-slate-800 shadow-top z-10">
      <div className="container mx-auto flex justify-around max-w-2xl">
        {TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex flex-col items-center justify-center w-full pt-2 pb-1 text-sm transition-colors duration-200 ${
              activeTab === tab.id
                ? 'text-indigo-600 dark:text-indigo-400'
                : 'text-slate-500 dark:text-slate-400 hover:text-indigo-500 dark:hover:text-indigo-400'
            }`}
          >
            <div className={`p-1 rounded-full transition-transform duration-200 ${activeTab === tab.id ? 'scale-110' : ''}`}>
              {/* FIX: Property 'Add' does not exist on type 'typeof Tab'. The condition referenced a non-existent enum member. */}
              <tab.icon className={'w-5 h-5'}/>
            </div>
            <span className={`mt-1 transition-colors ${activeTab === tab.id ? 'font-semibold' : ''}`}>{t(tab.titleKey)}</span>
          </button>
        ))}
      </div>
    </nav>
  );
};

export default BottomNav;