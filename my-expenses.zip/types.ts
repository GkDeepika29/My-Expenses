export type TransactionType = 'expense' | 'income';

export type RecurringFrequency = 'daily' | 'weekdays' | 'custom_weekly' | 'weekly' | 'custom_monthly' | 'monthly' | 'last_weekday_monthly';

export interface Category {
  id: string;
  name: string;
  icon: string;
  subCategories: string[];
}

export interface Budget {
    [key: string]: number; // Key can be category.id or a composite key like 'cat.id-subcategoryName'
}

export interface Transaction {
  id:string;
  type: TransactionType;
  amount: number;
  category: string; // This will be the category NAME for simplicity, could be ID
  subCategory?: string;
  date: string; // ISO string format
  notes: string;
  paymentMethod?: string;
  sourceRecurringId?: string;
}

export interface RecurringTransaction {
  id: string;
  type: TransactionType;
  amount: number;
  category: string; // Category NAME
  subCategory?: string;
  notes: string;
  paymentMethod?: string;
  frequency: RecurringFrequency;
  startDate: string; // The first date it should apply
  nextDueDate: string; // The next date it is due
  daysOfWeek?: number[]; // For custom_weekly, array of numbers 0-6 (Sun-Sat)
  dayOfMonth?: number; // For custom_monthly, 1-31 or -1 for last day
}

export enum Tab {
  Dashboard = 'dashboard',
  TransactionList = 'transactionList',
  Management = 'management',
  Import = 'import',
  Recurring = 'recurring',
  Export = 'export',
}

export type Language = 'en' | 'te' | 'ta' | 'hi';
export const ALL_LANGUAGES: Language[] = ['en', 'te', 'ta', 'hi'];


export type Currency = 'INR' | 'USD' | 'EUR' | 'KWD' | 'GBP' | 'JPY' | 'AUD' | 'CAD';

export interface Translations {
  [key: string]: {
    [lang in Language]?: string;
  };
}

export interface Notification {
  id: number;
  message: string;
  type: 'warning' | 'info';
}