import { RecurringTransaction, Transaction, RecurringFrequency } from '../types';

interface CustomScheduleOptions {
  daysOfWeek?: number[]; // 0-6 Sun-Sat
  dayOfMonth?: number; // 1-31 or -1 for last
}

export const calculateNextDueDate = (
  startDate: string,
  frequency: RecurringFrequency,
  options: CustomScheduleOptions = {}
): Date => {
  const date = new Date(startDate);
  // Set time to noon UTC to avoid timezone issues with date changes
  date.setUTCHours(12, 0, 0, 0);

  switch (frequency) {
    case 'daily':
      date.setUTCDate(date.getUTCDate() + 1);
      break;

    case 'weekdays':
      date.setUTCDate(date.getUTCDate() + 1);
      while (date.getUTCDay() === 0 || date.getUTCDay() === 6) { // Skip weekends (Sun=0, Sat=6)
        date.setUTCDate(date.getUTCDate() + 1);
      }
      break;

    case 'custom_weekly':
      if (!options.daysOfWeek || options.daysOfWeek.length === 0) return date; // Should not happen
      const sortedDays = options.daysOfWeek.sort();
      date.setUTCDate(date.getUTCDate() + 1);
      // Find the next valid day
      while (!sortedDays.includes(date.getUTCDay())) {
        date.setUTCDate(date.getUTCDate() + 1);
      }
      break;

    case 'weekly':
      date.setUTCDate(date.getUTCDate() + 7);
      break;
    
    case 'custom_monthly':
      const targetDay = options.dayOfMonth || 1;
      // Move to the next month
      date.setUTCMonth(date.getUTCMonth() + 1, 1); // Set to day 1 of next month
      
      if (targetDay === -1) {
        // Last day of the month
        date.setUTCMonth(date.getUTCMonth() + 1, 0); // Setting day to 0 gives last day of previous month
      } else {
        const lastDayOfNextMonth = new Date(date.getUTCFullYear(), date.getUTCMonth() + 1, 0).getUTCDate();
        date.setUTCDate(Math.min(targetDay, lastDayOfNextMonth));
      }
      break;

    case 'monthly':
      date.setUTCMonth(date.getUTCMonth() + 1);
      break;

    case 'last_weekday_monthly':
      // Move to the first day of the month after next
      date.setUTCMonth(date.getUTCMonth() + 2, 1);
      // Then go back to the last day of the desired month
      date.setUTCDate(0);
      // Now find the last weekday
      if (date.getUTCDay() === 6) { // Saturday
        date.setUTCDate(date.getUTCDate() - 1);
      } else if (date.getUTCDay() === 0) { // Sunday
        date.setUTCDate(date.getUTCDate() - 2);
      }
      break;
  }
  return date;
};

export const processRecurringTransactions = (
  recurringTxs: RecurringTransaction[],
  lastCheckStr: string | null
): { transactionsToAdd: Omit<Transaction, 'id'>[], updatedRecurringTxs: RecurringTransaction[] } => {
  const transactionsToAdd: Omit<Transaction, 'id'>[] = [];
  const updatedRecurringTxs = [...recurringTxs];
  const now = new Date();
  const lastCheck = lastCheckStr ? new Date(lastCheckStr) : new Date(0);

  updatedRecurringTxs.forEach((rtx, index) => {
    let nextDueDate = new Date(rtx.nextDueDate);
    
    while (nextDueDate <= now) {
      if (nextDueDate > lastCheck) {
        transactionsToAdd.push({
          type: rtx.type,
          amount: rtx.amount,
          category: rtx.category,
          subCategory: rtx.subCategory,
          date: nextDueDate.toISOString(),
          notes: rtx.notes,
          paymentMethod: rtx.paymentMethod,
          sourceRecurringId: rtx.id,
        });
      }

      nextDueDate = calculateNextDueDate(nextDueDate.toISOString(), rtx.frequency, {
        daysOfWeek: rtx.daysOfWeek,
        dayOfMonth: rtx.dayOfMonth
      });
    }

    updatedRecurringTxs[index].nextDueDate = nextDueDate.toISOString();
  });

  return { transactionsToAdd, updatedRecurringTxs };
};
