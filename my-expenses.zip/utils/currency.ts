import { Currency, Language } from '../types';

export const formatCurrency = (amount: number, currency: Currency, language: Language, maximumFractionDigits: number = 2): string => {
  return new Intl.NumberFormat(language, {
    style: 'currency',
    currency: currency,
    maximumFractionDigits: maximumFractionDigits,
  }).format(amount);
};