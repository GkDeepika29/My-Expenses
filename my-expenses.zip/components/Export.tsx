import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Transaction } from '../types';

interface ExportProps {
  transactions: Transaction[];
}

const Export: React.FC<ExportProps> = ({ transactions }) => {
  const { t } = useLanguage();
  const [isExporting, setIsExporting] = useState(false);

  const escapeCsvField = (field: string | undefined): string => {
    if (field === undefined || field === null) {
      return '';
    }
    const stringField = String(field);
    // If the field contains a comma, double-quote, or newline, wrap it in double-quotes.
    if (stringField.includes(',') || stringField.includes('"') || stringField.includes('\n')) {
      // Also, any double-quotes inside the field must be escaped by another double-quote.
      return `"${stringField.replace(/"/g, '""')}"`;
    }
    return stringField;
  };

  const handleExport = () => {
    setIsExporting(true);

    const header = ['date', 'type', 'amount', 'category', 'subCategory', 'paymentMethod', 'notes'];
    const rows = transactions.map(tx => [
      tx.date,
      tx.type,
      tx.amount,
      tx.category,
      tx.subCategory,
      tx.paymentMethod,
      tx.notes
    ].map(escapeCsvField).join(','));

    const csvContent = [header.join(','), ...rows].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.href) {
      URL.revokeObjectURL(link.href);
    }
    link.href = URL.createObjectURL(blob);
    link.download = `my-expenses-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    setIsExporting(false);
  };

  return (
    <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg animate-fade-in max-w-lg mx-auto">
        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200 mb-2">{t('exportData')}</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
            {t('exportAsCsv')}
        </p>
        <div className="mt-6">
            <button 
                onClick={handleExport}
                disabled={isExporting}
                className="w-full cursor-pointer inline-flex items-center justify-center px-4 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
            >
                {isExporting ? t('processing') : t('exportTitle')}
            </button>
        </div>
    </div>
  );
};

export default Export;