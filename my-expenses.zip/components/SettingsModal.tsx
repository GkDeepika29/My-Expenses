import React from 'react';
import { Language, Currency } from '../types';
import { LANGUAGES, CURRENCIES } from '../constants';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  aiConsent: boolean;
  setAiConsent: (consent: boolean) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ 
    isOpen, onClose, currency, setCurrency, 
    aiConsent, setAiConsent
}) => {
  const { language, setLanguage, t } = useLanguage();
  const { theme, setTheme } = useTheme();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 animate-fade-in-fast" onClick={onClose}>
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl p-6 w-full max-w-md m-4 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <h2 className="text-2xl font-bold mb-6 text-slate-800 dark:text-slate-100">{t('settingsTitle')}</h2>
        
        <div className="space-y-8">
          {/* General Settings */}
          <fieldset className="space-y-4">
            <div>
              <label htmlFor="currency" className="block text-sm font-medium text-slate-700 dark:text-slate-300">{t('currency')}</label>
              <select id="currency" value={currency} onChange={(e) => setCurrency(e.target.value as Currency)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                {CURRENCIES.map(c => <option key={c.id} value={c.id}>{c.name} ({c.symbol})</option>)}
              </select>
            </div>
             <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">{t('theme')}</label>
                <div className="mt-1 grid grid-cols-2 gap-2 rounded-md bg-slate-100 dark:bg-slate-700 p-1">
                    <button onClick={() => setTheme('light')} className={`px-3 py-1 text-sm font-medium rounded ${theme === 'light' ? 'bg-white dark:bg-slate-500 shadow text-indigo-700 dark:text-white' : 'text-slate-600 dark:text-slate-300'}`}>{t('light')}</button>
                    <button onClick={() => setTheme('dark')} className={`px-3 py-1 text-sm font-medium rounded ${theme === 'dark' ? 'bg-white dark:bg-slate-500 shadow text-indigo-700 dark:text-white' : 'text-slate-600 dark:text-slate-300'}`}>{t('dark')}</button>
                </div>
            </div>
            <div>
              <label htmlFor="language" className="block text-sm font-medium text-slate-700 dark:text-slate-300">{t('language')}</label>
              <select id="language" value={language} onChange={(e) => setLanguage(e.target.value as Language)} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                {LANGUAGES.map(lang => <option key={lang.id} value={lang.id}>{lang.name}</option>)}
              </select>
            </div>
          </fieldset>
          
          {/* AI Consent */}
          <fieldset className="pt-2">
             <label className="flex items-start">
                <input type="checkbox" checked={aiConsent} onChange={(e) => setAiConsent(e.target.checked)} className="h-5 w-5 rounded border-gray-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500 mt-0.5 bg-transparent dark:bg-slate-900" />
                <span className="ml-3 text-sm text-gray-700 dark:text-slate-300">
                    <span className="font-medium">{t('enableAi')}</span>: {t('aiConsentPrompt')}
                </span>
            </label>
          </fieldset>
        </div>

        <div className="mt-8 flex justify-end">
          <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700">{t('close')}</button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;