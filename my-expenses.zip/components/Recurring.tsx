import React from 'react';
import { Currency, RecurringTransaction } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { formatCurrency } from '../utils/currency';
import { TrashIcon } from './icons';

interface RecurringProps {
    recurringTransactions: RecurringTransaction[];
    deleteRecurringTransaction: (id: string) => void;
    currency: Currency;
}

const Recurring: React.FC<RecurringProps> = ({ recurringTransactions, deleteRecurringTransaction, currency }) => {
    const { t, language } = useLanguage();

    const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString(language, {
        year: 'numeric', month: 'short', day: 'numeric'
    });

    if (recurringTransactions.length === 0) {
        return (
            <div className="text-center py-20 animate-fade-in">
                <p className="text-slate-500 dark:text-slate-400">{t('noRecurringTransactions')}</p>
            </div>
        );
    }

    return (
        <div className="space-y-4 animate-fade-in">
            {recurringTransactions.map(rtx => (
                <div key={rtx.id} className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-md flex justify-between items-center">
                    <div>
                        <p className={`font-semibold ${rtx.type === 'income' ? 'text-green-700 dark:text-green-400' : 'text-red-700 dark:text-red-400'}`}>
                            {rtx.category} {rtx.subCategory ? `> ${rtx.subCategory}` : ''}
                        </p>
                        <p className="text-sm text-slate-600 dark:text-slate-300">{t(rtx.frequency)}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{t('nextDue')}: {formatDate(rtx.nextDueDate)}</p>
                    </div>
                    <div className="flex items-center space-x-4">
                        <span className={`font-bold text-lg ${rtx.type === 'income' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                            {formatCurrency(rtx.amount, currency, language)}
                        </span>
                        <button 
                            onClick={() => deleteRecurringTransaction(rtx.id)} 
                            className="p-2 text-red-500 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900/50 rounded-full transition-colors"
                            aria-label={`${t('delete')} ${rtx.category} recurring transaction`}
                        >
                            <TrashIcon className="w-5 h-5" />
                        </button>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default Recurring;